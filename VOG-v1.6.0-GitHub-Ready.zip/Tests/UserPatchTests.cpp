#include "UserPatches.h"
#include <iostream>
int main(){
 const auto folder=juce::File::getSpecialLocation(juce::File::tempDirectory).getNonexistentChildFile("VOG-Patch-Test-"+juce::Uuid().toString(),"");
 struct Cleanup{juce::File folder;~Cleanup(){folder.deleteRecursively();}} cleanup{folder};
 davoe::UserPatches bank(folder);
 juce::String first,second;
 const char one[]="original",two[]="edited";
 const juce::MemoryBlock a(one,sizeof(one)),b(two,sizeof(two));
 if(bank.add("  ",a,first).wasOk()||!bank.names().isEmpty()){
  std::cerr<<"A blank patch name was accepted or created a file.\n";return 1;
 }
 if(const auto result=bank.add("My Bass",a,first);result.failed()){
  std::cerr<<"Could not save original patch: "<<result.getErrorMessage().toStdString()<<'\n';return 2;
 }
 if(const auto result=bank.add("My Bass",b,second);result.failed()){
  std::cerr<<"Could not save duplicate patch: "<<result.getErrorMessage().toStdString()<<'\n';return 2;
 }
 if(first==second){std::cerr<<"Duplicate save reused the original name.\n";return 2;}
 davoe::UserPatches reopened(folder);
 const auto names=reopened.names();
 if(names.size()!=2||!names.contains(first)||!names.contains(second)){
  std::cerr<<"Reopened library does not list both saved patches.\n";return 3;
 }
 // JUCE appends file bytes to the destination block, so each read starts empty.
 juce::MemoryBlock original,duplicate;
 if(!reopened.fileFor(first).loadFileAsData(original)||original!=a){
  std::cerr<<"Original patch failed to reload or its bytes changed.\n";return 4;
 }
 if(!reopened.fileFor(second).loadFileAsData(duplicate)||duplicate!=b){
  std::cerr<<"Duplicate patch failed to reload or its bytes changed.\n";return 5;
 }
 std::cout<<"PASS: new names, duplicate save preserves original, library persists and data reloads\n";
}
