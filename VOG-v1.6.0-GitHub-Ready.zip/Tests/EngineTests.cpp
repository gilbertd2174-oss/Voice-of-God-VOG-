#include "SynthEngine.h"
#include "Presets.h"
#include "WaveCapture.h"
#include <iostream>
#include <stdexcept>
#include <limits>
void require(bool ok,const char* text){if(!ok)throw std::runtime_error(text);}
float render(davoe::Engine& e,int samples){float peak=0;for(int i=0;i<samples;i++){float l,r;e.sample(l,r,120);require(std::isfinite(l)&&std::isfinite(r),"Non-finite output");require(std::abs(l)<=1.001f&&std::abs(r)<=1.001f,"Output protection failed");peak=std::max(peak,std::max(std::abs(l),std::abs(r)));}return peak;}
int main(){try{
 {
  davoe::Engine e;e.prepare(8000);auto p=davoe::defaults();
  p[davoe::ArpOn]=p[davoe::ArpHold]=p[davoe::Noise]=p[davoe::DistOn]=1;
  p[davoe::ArpChord]=7;p[davoe::Feedback]=.85f;p[davoe::Reverb]=.8f;
  e.setParameters(p);
  require(render(e,16000)==0&&e.activeVoices()==0,"Idle arp or effects produced startup audio");
  e.noteOn(60,.8f);e.noteOff(60);
  require(render(e,1600)>.001f,"First note did not wake the arp");
  e.panic();
  require(render(e,16000)==0&&e.activeVoices()==0,"Panic did not silence held chords and effects");
  e.noteOn(60,.8f);
  require(render(e,1600)>.001f,"Arp did not wake after panic");
 }

 {
  davoe::Engine e;e.prepare(8000);auto p=davoe::presets[19].values;
  p[davoe::ArpOn]=1;p[davoe::ArpRate]=2;p[davoe::ArpScale]=1;p[davoe::ArpOctaves]=2;
  e.setParameters(p);e.noteOn(67,.7f);e.noteOn(60,.8f);
  const int expected[]={60,62,64,65,67,69,71,72,74};
  for(size_t i=0;i<sizeof(expected)/sizeof(*expected);++i){render(e,i==0?1:1000);require(e.currentArpNote()==expected[i],"Incorrect major scale step or octave");}
  e.panic();p[davoe::ArpMode]=1;p[davoe::ArpScale]=2;e.setParameters(p);e.noteOn(125,.8f);render(e,1);
  require(e.currentArpNote()==127,"Down direction or MIDI ceiling failed");render(e,1000);require(e.currentArpNote()==125,"Scale exceeded MIDI ceiling or failed to wrap");
  e.noteOff(125);require(e.currentArpNote()==-1,"Scale did not stop after key release");
 }

 {
  davoe::Engine e;e.prepare(8000);auto p=davoe::defaults();
  p[davoe::ArpOn]=1;p[davoe::ArpRate]=2;p[davoe::ArpScale]=1;p[davoe::ArpChord]=7;
  p[davoe::ArpGate]=.5f;p[davoe::AmpR]=20;p[davoe::ArpOctaves]=2;p[davoe::Mono]=1;
  e.setParameters(p);e.noteOn(60,.8f);render(e,1);
  const int chord[]={60,63,67,70,72,75,79,82};
  for(size_t i=0;i<sizeof(chord)/sizeof(*chord);++i)
   require(e.currentArpNote(i)==chord[i],"Incorrect minor seventh chord voicing");
  require(e.activeVoices()==8&&e.currentArpNote(8)==-1,"Chord notes must start together, even on mono patches");
  render(e,500);require(e.currentArpNote()==-1,"Chord gate failed to release");
  render(e,500);require(e.currentArpNote(7)==82,"Chord did not repeat");
  e.noteOff(60);require(e.currentArpNote()==-1,"Chord did not stop on release");
  render(e,500);require(e.activeVoices()==0,"Chord left a stuck voice");
  p[davoe::ArpChord]=0;e.setParameters(p);e.noteOn(60,.8f);render(e,1);
  require(e.currentArpNote()==60&&e.currentArpNote(1)==-1,"Switching Chord off did not resume scale");
  e.panic();p[davoe::ArpOn]=0;p[davoe::Mono]=0;e.setParameters(p);
  e.noteOn(60,.8f);e.noteOn(64,.8f);e.noteOn(67,.8f);
  render(e,1);require(e.activeVoices()==3,"Manual chord playing failed");
 }

 require(davoe::arpStepLength(48000,5,5)==2304000.,"Wrong 1/1 timing at 5 BPM");
 require(davoe::arpStepLength(48000,5,6)==1152000.,"Wrong 1/2 timing at 5 BPM");
 require(davoe::arpStepLength(48000,120,7)==32000.,"Wrong 1/3 timing");
 {
  davoe::WaveCapture capture;require(!capture.begin(0)&&capture.begin(8000),"Invalid capture rate handling");
  std::array<float,1024> l{},r{};l[0]=1;r[0]=-1;
  capture.append(l.data(),r.data(),1);capture.stop();require(capture.finishHeader(),"Could not finish short WAV");
  auto b=capture.data();require(capture.size()==48&&b[0]=='R'&&b[8]=='W'&&b[22]==2&&b[34]==16&&b[40]==4,"Invalid stereo WAV header");
  require(b[44]==255&&b[45]==127&&b[46]==0&&b[47]==128,"Incorrect stereo PCM data");
  require(capture.begin(8000),"Could not start fresh take");
  while(capture.active())capture.append(l.data(),r.data(),(int)l.size());
  require(capture.frameCount()==8000*180&&capture.finishHeader(),"Recording exceeded three-minute limit");
 }
 {
  davoe::Engine e;e.prepare(8000);auto p=davoe::presets[19].values;p[davoe::AmpR]=20;p[davoe::ArpHold]=1;e.setParameters(p);
  e.noteOn(60,.8f);e.noteOff(60);require(render(e,2400)>.001f&&e.activeVoices()==1,"Hold without arp failed");
  e.noteOn(64,.8f);render(e,2400);require(e.activeVoices()==1,"New chord did not replace held notes");e.noteOff(64);
  p[davoe::ArpHold]=0;e.setParameters(p);render(e,2400);require(e.activeVoices()==0,"Hold off did not release notes");
  p[davoe::ArpOn]=1;p[davoe::ArpRate]=5;p[davoe::ArpGate]=.1f;p[davoe::Tempo]=5;p[davoe::ArpClock]=1;e.setParameters(p);
  e.noteOn(60,.8f);render(e,8000);require(e.activeVoices()==1,"Internal 5 BPM arp clock did not override host clock");
  e.noteOff(60);render(e,2400);require(e.activeVoices()==0,"Slow arp did not release promptly");
 }

 for(const auto& patch:davoe::presets){for(size_t i=0;i<patch.values.size();i++)require(patch.values[i]>=davoe::specs[i].lo&&patch.values[i]<=davoe::specs[i].hi,"Preset outside parameter range");}
 for(double sr:{44100.,48000.,96000.}){
  davoe::Engine e;e.prepare(sr);auto p=davoe::presets[19].values;p[davoe::AmpR]=20;e.setParameters(p);
  render(e,3000);require(e.activeVoices()==0,"Silence created voices");
  e.noteOn(69,.8f);require(render(e,(int)(sr*.3))>.001f,"No note audio");e.noteOff(69);render(e,(int)sr);require(e.activeVoices()==0,"Stuck note after release");
  e.controller(64,127);e.noteOn(60,.8f);e.noteOff(60);render(e,1000);require(e.activeVoices()>0,"Sustain not holding");e.controller(64,0);render(e,(int)sr);require(e.activeVoices()==0,"Sustain pedal stuck");
  for(int n=40;n<80;n++)e.noteOn(n,.8f);require(e.activeVoices()==16,"Voice allocation/stealing failed");render(e,2000);e.panic();require(render(e,100)==0,"Panic did not clear voices and tails");
  p[davoe::ArpOn]=1;p[davoe::ArpHold]=0;e.setParameters(p);e.noteOn(60,.9f);e.noteOn(64,.8f);e.noteOn(67,.7f);require(render(e,(int)sr)>.001f,"Arpeggiator silent");e.noteOff(60);e.noteOff(64);e.noteOff(67);render(e,(int)sr*2);require(e.activeVoices()==0,"Arpeggiator stuck after release");
  e.panic();p[davoe::ArpHold]=1;e.setParameters(p);e.noteOn(60,.8f);e.noteOff(60);require(render(e,(int)sr)>.001f,"Latch failed");e.panic();require(render(e,100)==0,"Panic failed with latch");
 }
 for(int osc=0;osc<4;osc++){
  davoe::Engine e;e.prepare(48000);auto p=davoe::presets[19].values;
  p[davoe::Level1]=p[davoe::Level2]=p[davoe::Level3]=p[davoe::Level4]=0;
  const davoe::Param levels[]={davoe::Level1,davoe::Level2,davoe::Level3,davoe::Level4};p[levels[osc]]=.6f;e.setParameters(p);e.noteOn(69,.8f);render(e,24000);require(render(e,24000)>.001f,"An independent oscillator is silent");
 }
 for(const auto& patch:davoe::presets){davoe::Engine e;e.prepare(48000);e.setParameters(patch.values);e.noteOn(48,.9f);e.noteOn(55,.75f);e.noteOn(60,.8f);require(render(e,48000)>.00001f,"Silent factory preset");e.noteOff(48);e.noteOff(55);e.noteOff(60);render(e,24000);}
 // Every waveform/filter/distortion route and both synced modulators must remain finite.
 for(int wave=0;wave<4;wave++)for(int filter=0;filter<3;filter++)for(int dist=0;dist<3;dist++){
  davoe::Engine e;e.prepare(48000);auto p=davoe::defaults();p[davoe::Wave1]=(float)wave;p[davoe::FilterMode]=(float)filter;p[davoe::DistMode]=(float)dist;p[davoe::DistOn]=1;p[davoe::DistDrive]=1;p[davoe::Resonance]=.95f;p[davoe::FxDepth]=1;p[davoe::FxSync]=1;p[davoe::EchoSync]=1;p[davoe::EchoHeads]=3;p[davoe::Reverb]=.65f;
  e.setParameters(p);e.noteOn(90,1);render(e,12000);
 }
 std::cout<<"PASS: preset ranges, three sample rates, MIDI release/sustain, 16-voice stealing, arp/latch/panic, all presets and effects routes\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
