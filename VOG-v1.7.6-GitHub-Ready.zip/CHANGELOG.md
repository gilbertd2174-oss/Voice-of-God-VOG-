# 1.7.6
- Set the large VOG title and panel headings in Bahnschrift SemiBold.
- Added gold musical-note accents around the O in the wordmark.

# 1.7.5
- Tripled the VOG title size and rearranged the header controls to fit beside it.
- Corrected invalid attack values in ten acid-bass presets.

# 1.7.4
- Added sculpted navy knob faces, machined grips, thin grey rims, and inset position markers.
- Enlarged the VOG title and matched its font to the control labels.

# 1.7.3
- Changed the knob faces to navy blue with thin grey rims.

# 1.7.2
- Reduced the width of the grey knob rings from 4 to 2 pixels at 100% zoom.

# 1.7.1
- Changed the knob rings from yellow gold to brushed grey.

# 1.7.0
- Added 100 new factory sounds while keeping the original preset numbers.
- Extended the arpeggiator range to four octaves and displayed Gate as a percentage.
- Replaced the modal Save Patch window with an in-editor name field and explicit Save and Cancel actions.
- Changed the knob rings to yellow gold.
- Stretched the six-octave keyboard across the burgundy case, with pitch and modulation wheels at left.

# 1.6.1
- Removed the fixed 4 dB output boost and reduced the factory output trim to -15 dB.
- Added a stereo-linked -12 dBFS peak ceiling after effects. Saved output trim is applied before the first note.

# 1.6.0
- Added a GUI zoom menu with nine sizes from 60% to 150%.
- The VST3 starts at 85% by default. FIT resets the window for the current screen.

# 1.5.2
- Keep the effects silent before the first note and clear quiet or expired effect tails.
- Skip arpeggiator processing when no notes are held.
- Clear latched notes and effects when the DAW transport stops.

# 1.5.1
- Fixed the user patch library test to read each saved file into its own buffer.
- Added a specific error message for each patch test failure.

# 1.5.0
- Added seven one-key chord types to the arpeggiator. Chord mode repeats full voicings across the selected octaves.
- Kept the scale runs and the synth’s manual polyphonic playing.

# 1.4.0
Added six scale modes to the arpeggiator, using the lowest held key as the root, with the existing octave, direction and Hold controls.

# 1.3.6
Use the supported JUCE 8.0.6 TextEditor single-line API. Report the first compiler/linker diagnostics at the end of failed builds.

# 1.3.5
VST3 opens in a smaller 820 × 520 window and FIT returns to that size. Standalone sizing is unchanged.

# 1.3.4
Smaller opening size, FIT button, narrower minimum, and compact settings layout.

# 1.3.3
Moved arpeggiator dropdown labels directly above their boxes.

# 1.3.2
Reduced arpeggiator panel height from 202 to 172 pixels. Its centered controls retain their large format.

# 1.3.1
Centered the large Octaves, Gate and Tempo controls in the arpeggiator, with the selectors on either side.

# 1.3.0
Named user patches, separate patch-file menu, black control panels, and arpeggiator above all synth settings.

# 1.2.0
Hold for normal notes and arp, three long divisions, 5 BPM internal clock, larger arp controls, burgundy/blue finish, +4 dB output boost, and three-minute stereo WAV capture.

# 1.1.0
Search and filter the original 100 presets, step through matches, and use narrower windows without horizontal scrolling. Improved knob contrast and ivory numeric readouts.

# 1.0.2
Remove unsupported MidiKeyboardComponent::setTooltip call (MSVC C2039). Keyboard playing instructions remain in the status bar and README.

# 1.0.1
Fix MSVC C2440 in Save/Load callbacks: construct the editor SafePointer in the editor constructor and capture that typed guard in asynchronous callbacks.

# 1.0.0
Initial Davoe analog-style instrument: four independent oscillators, synth page, effects rack, 100 presets, patch storage, Windows VST3 and standalone build configuration.
