# Voice of God

A Windows x64 VST3 instrument and standalone synthesizer, with an original vintage panel inspired by the supplied keyboard references. Two interface pages: SYNTHESIZER and EFFECTS RACK. No reference-product logos, artwork, samples or source code are included.

## Sound engine
- 16-voice polyphony with voice stealing, or last-note-priority mono with glide.
- Four independently tunable oscillators: polyBLEP saw/pulse, additive band-limited triangle, and sine; sub oscillator and white noise.
- Low-pass, high-pass and band-pass resonant filter, keyboard tracking and independent amp/filter ADSR envelopes.
- One global LFO: sine, triangle, square and sample/hold; pitch, cutoff, PWM and tremolo destinations. MIDI modulation wheel adds vibrato.
- Arpeggiator: up/down/up-down/random, 1–3 octaves, five note divisions, gate and chord latch. Host BPM takes priority; fallback tempo works standalone. Timing is sample-based and tempo-synced, not tied to the DAW song-position grid.
- Stereo chorus, stereo spread, pitch wheel, sustain pedal, sample-position MIDI events and Panic.

## Effects rack
Fixed order: compressor → seven-band EQ → distortion/tone → chorus → tape echo → reverb → master/output protection.
- Stereo-linked compressor: threshold, ratio, attack, release, makeup, parallel mix and gain-reduction VU display.
- Seven bell-EQ bands: 100, 200, 400, 800, 1600, 3200 and 6400 Hz; ±15 dB and shared Q.
- Tube, fuzz and saturation algorithms, drive, three-band tone controls, output and wet/dry blend. Distortion uses an interpolated two-sample waveshaping pass; it is not a circuit emulation or a high-quality oversampling system.
- Multi-head tape-style echo: four head combinations, wow/flutter, feedback, mix and dotted-eighth tempo sync (40–1000 ms range).
- Algorithmic reverb: pre-delay, early reflections, room size, decay, damping, input high/low-pass and delay modulation.
- Effects modulator: free or quarter-note sync, waveform, depth, optional mod-wheel scaling and note-on phase reset. Destinations are echo feedback, reverb mix and chorus delay depth.

## Factory sound banks
01–20: original collection; 21–36: bass; 37–52: leads; 53–68: pads/strings; 69–84: keys/plucks/organs; 85–100: arpeggios and experiments. 101–200 add sub basses, acid basses, leads, keys, plucks, pads, strings, bells, scale arps and chord arps. All 200 sounds use synthesis.

## Play and save
1. In a DAW, put this on a MIDI/instrument track and enable your MIDI keyboard input. It is an instrument, not an audio insert effect.
2. Click the on-screen keys. Click the keyboard before using computer keys A W S E D F T G Y H U J K.
3. Choose one of 200 factory patches. SAVE PATCH and LOAD PATCH write/read .vog state files. DAW sessions restore all parameter values.
4. PANIC stops voices, clears arp latch, resets sustain and clears effects tails. Release physically held MIDI keys before playing again.
5. Hover for tooltips; double-click knobs/faders to reset. Type into numeric boxes for precise values. Resize or scroll when needed.

## Easy GitHub build — use a NEW repository
Keep this synthesizer separate from the vocal-processor repository.
1. Upload VOG-v1.7.13-GitHub-Ready.zip intact to the root of your new GitHub repository and commit.
2. Create .github/workflows/main.yml and paste the entire contents of the supplied VOG-v1.7.13-main.yml into it, then commit.
3. Open Actions → VOG Windows Build. The workflow extracts the uploaded ZIP, builds VST3 and standalone, runs engine tests and uploads the Windows package.
4. Download the Voice-of-God-Windows-x64-v1.7.13 artifact, extract it and any inner ZIP. Follow INSTALL.md.

Alternatively, extract this source ZIP and upload ALL its contents, including Source, Tests, scripts and .github. In that case it builds directly without unpacking.

## Local Windows build
Install Visual Studio 2022 with Desktop development with C++, Windows SDK and CMake tools; also Git for Windows. In PowerShell from the extracted source folder:

    ./scripts/build-windows.ps1 -Configuration Release -Parallel 2

Requires internet on first configure to fetch JUCE 8.0.6. Output:

    dist/Voice-of-God-Windows-x64.zip

For engine tests without JUCE, use CMake with -DDAVOE_ENGINE_ONLY=ON -DBUILD_TESTING=ON, build and run ctest.

See VALIDATION.md for the actual verification status. Source delivery is not a compiled binary. This is an initial implementation, not a sound-identical recreation of the instrument pictured.

## Framework documentation
JUCE: https://docs.juce.com/master/classjuce_1_1AudioProcessorValueTreeState.html
JUCE licensing: https://juce.com/legal/juce-8-licence/

### Preset browser (1.1.0)
Search factory presets by name or number and filter by sound family. The arrows cycle only through matches. Enter loads a single match; Esc clears search and returns focus to the keyboard. Filtering never changes the sound until you select a preset. Narrow windows stack the panels, with the keyboard and controls still accessible. Original program order, patch format and synthesis are unchanged.

## 1.2.0
Hold sustains notes with the arp on or off. After releasing the keys, playing a new chord replaces the held notes. Switch Hold off or press PANIC to clear them.
Arp Clock = Internal uses 5–240 BPM even in a host; DAW follows host BPM when supplied. 1/1 is four beats, 1/2 is two beats, and 1/3 is one third of a whole note (4/3 beats in 4/4). The default tempo is still 120 BPM. Older preset division indices are retained; check existing host automation for Tempo and Division because their parameter ranges changed.
Output has an extra 4 dB before the existing soft limiter. The output knob is the trim before this fixed boost.
Click REC, play, then click STOP or let it stop at 03:00. Click SAVE WAV to write the take. Recording captures this instrument after effects and output protection, before your DAW mixer and inserts, as 16-bit stereo PCM at the current audio sample rate (8–192 kHz). The host must be processing audio. Starting a new take replaces the in-memory take, so save it first if you want to keep it.

## 1.3.0
Save Patch now creates a named User Patch and switches the browser to it. Saved patches are listed under User Patches or All sounds, and are available after reopening the synth. A duplicate name makes a numbered copy. Patch Files provides .vog import/export and Refresh User Patches. Importing a file loads the sound; Save Patch adds it to the library. The library lives in the Windows user application data folder under Davoe Audio / Voice of God / User Patches. Projects still store their own sound settings and the host factory program count stays at 100.
The arpeggiator is above all synth settings boxes. Knob panels are black with dark red outlines; the background between panels is burgundy.

## Smaller windows (1.3.4)
The editor starts at up to 1200 × 760 logical pixels and leaves space for the taskbar and host window chrome. Click FIT by the VOG title to reset to the compact size for the current display. Drag the lower-right corner to resize down to 720 × 440. Narrow windows stack panels and put the arp dropdowns in a separate row. Scroll the settings while keeping the keyboard and top controls in view. Some DAWs can restore their own window size.

## Compact VST3 window (1.3.5)
The VST3 opens at up to 820 × 520 logical pixels, and FIT returns it to that size. The standalone keeps its 1200 × 760 maximum opening size. Both use the display work area when available. Reason 14 on Windows can separately enlarge a VST: Options → Manage Plugins → Voice of God → Auto-scale (follow Windows display scaling). If enabled and the window is too large, turn it off for VOG and reload the plugin. See https://docs.reasonstudios.com/reason14/working-with-vst-plugins .

## Scale arpeggiator (1.4.0)
Turn Arpeggiator on and choose Scale, then hold one key as the root. If you hold a chord, the lowest held key is the root. Choose Major, Natural minor, Harmonic minor, Major pentatonic, Minor pentatonic or Chromatic. Octaves sets how far the run spans, and Direction sets how it travels. Hold keeps it going when you release the keys. Scale Off arpeggiates the notes you play. The new parameter defaults to Off in factory patches.

## Chord arpeggiator (1.5.0)
Turn Arpeggiator on, choose a Chord type, and hold a root key. Major, Minor, Sus2, Sus4, Dominant 7, Major 7 and Minor 7 are available. The lowest held key sets the root. All chord tones sound together, even when the current patch uses Mono. Octaves adds voicings in higher registers, Division sets the repeat rate, Gate sets the length, and Hold latches the root. Chord takes priority over Scale. Turn Chord off for scale runs, or turn both off to arpeggiate the notes you hold. To play your own chords together, turn Arpeggiator off and select Voice mode: Poly 16.

## GUI zoom (1.6.0)
Use the percentage menu next to the title to resize the full interface. VST3 starts at 85% (about 697 × 442 logical pixels before host scaling). Standalone starts at 100%. The menu offers 60%, 70%, 75%, 85%, 90%, 100%, 110%, 125% and 150%. VOG remembers the zoom while the plug-in instance stays loaded. FIT restores a compact size for the display. If Reason enlarges the window, turn off Auto-scale for Voice of God in Options → Manage Plugins, then reopen the plug-in.

## Output protection (1.6.1)
Factory patches start at -15 dB output trim. The output limiter caps sample peaks at -12 dBFS after effects. The DAW mixer and inserts can apply additional gain after VOG. Saved output trim is applied when the audio engine starts.

## USB keyboard response (1.7.7)
Open Performance → Velocity curve. Auto uses Gentle in the standalone app and Linear in a DAW. Gentle brings up soft strikes and tames the strongest ones. Fixed plays every strike at the same level. Set Held level to Steady to avoid amplitude and filter envelope decay until key release. Patch uses the preset envelope. The arpeggiator gate still controls how long arp notes sound. These settings are saved with the patch.

## Oscillator gates and WAV level (1.7.9)
Each main oscillator has a GATE ON/OFF button. It fades that source in or out while preserving its level setting. The sub oscillator and noise remain in the Source Mixer. Gates default to On in older patches.

SAVE WAV applies a shared stereo gain of up to 24 dB, targeting a peak of -1 dBFS. The gain is applied once per take. Silence stays silent. Live playback uses the regular output level.
