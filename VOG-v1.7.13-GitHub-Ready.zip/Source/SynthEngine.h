#pragma once
#include "Parameters.h"
#include <vector>
#include <cstdint>
namespace davoe {
constexpr float pi=3.14159265358979323846f;
constexpr float outputPeakCeiling=.25118864f; // -12 dBFS
struct Envelope {
 enum Stage { Idle,Attack,Decay,Sustain,Release } stage=Idle;
 float value=0, releaseStep=0;
 void on(){stage=Attack;}
 void off(float ms,float sr,bool shorten=false){
  if(stage==Idle||(stage==Release&&!shorten))return;
  const float step=value/std::max(1.f,ms*.001f*sr);
  releaseStep=stage==Release?std::max(releaseStep,step):step;
  stage=Release;
 }
 void reset(){stage=Idle;value=0;}
 float tick(float a,float d,float s,float sr){
  switch(stage){
   case Attack:value+=1.f/std::max(1.f,a*.001f*sr);if(value>=1){value=1;stage=Decay;}break;
   case Decay:value-=(1-s)/std::max(1.f,d*.001f*sr);if(value<=s){value=s;stage=Sustain;}break;
   case Sustain:value=s;break;
   case Release:value-=releaseStep;if(value<=0){value=0;stage=Idle;}break;
   default:break;
  }return value;
 }
};
inline float blep(float t,float dt){
 if(t<dt){t/=dt;return t+t-t*t-1;}
 if(t>1-dt){t=(t-1)/dt;return t*t+t+t+1;}
 return 0;
}
inline float bandGain(float cyclesPerSample){return clamp((.48f-cyclesPerSample)/.08f,0.f,1.f);}
inline float oscillator(float phase,float dt,int shape,float pw){
 if(shape==0)return 2*phase-1-blep(phase,dt);
 if(shape==1){float q=phase-pw;if(q<0)q+=1;return (phase<pw?1.f:-1.f)+blep(phase,dt)-blep(q,dt);}
 // Triangle uses a finite band-limited odd-harmonic series, avoiding corner aliasing.
 if(shape==2){float y=0;for(int h=1;h<=15;h+=2){if(h*dt>=.48f)break; y+=(((h-1)/2)%2?-1.f:1.f)*std::sin(2*pi*phase*h)/(float)(h*h);}return y*.81056947f;}
 return std::sin(2*pi*phase);
}
struct Filter {
 float s1=0,s2=0;
 void reset(){s1=s2=0;}
 float tick(float x,float hz,float res,int mode,float sr){
  float g=std::tan(pi*clamp(hz,20.f,sr*.42f)/sr),k=2.f-1.9f*res;
  float a=1.f/(1.f+g*(g+k));float v1=a*(s1+g*(x-s2));float v2=s2+g*v1;
  s1=2*v1-s1;s2=2*v2-s2;
  return mode==0?v2:(mode==1?x-k*v1-v2:v1);
 }
};
struct Voice {
 int note=-1,channel=0;uint64_t age=0;float velocity=0,phase1=0,phase2=.23f,phase3=.47f,phase4=.71f,phaseSub=0,pitch=60,pan=0;
 Envelope amp,env;Filter filter;
 bool active()const{return amp.stage!=Envelope::Idle;}
 void start(int n,int ch,float vel,uint64_t stamp,bool legato,float sr,const Values& p){
  bool was=active()&&amp.stage!=Envelope::Release;note=n;channel=ch;velocity=vel;age=stamp;
  if(!legato||!was){pitch=(float)n;phase1=0;phase2=.23f;phase3=.47f;phase4=.71f;phaseSub=0;filter.reset();amp.reset();env.reset();}
  if(!legato||!was){amp.on();env.on();}
  pan=((n*37%101)/100.f-.5f)*p[Spread];(void)sr;
 }
 void release(float sr,const Values& p,float maxMs=8000.f){
  const bool shorten=maxMs<8000.f;
  amp.off(std::min(p[AmpR],maxMs),sr,shorten);
  env.off(std::min(p[FilterR],maxMs),sr,shorten);
 }
};
struct DelayLine {
 std::vector<float> data;int pos=0;
 void prepare(int size){data.assign((size_t)std::max(4,size),0);pos=0;}
 void reset(){std::fill(data.begin(),data.end(),0);pos=0;}
 float read(float samples)const{
  if(!std::isfinite(samples))return 0.f;
  const int length=(int)data.size();
  const float delay=clamp(samples,1.f,(float)(length-2));
  const int whole=(int)delay;
  // Wrap integer taps before interpolating. A float wrap can round up to length.
  int newer=pos-whole;
  if(newer<0)newer+=length;
  const int older=newer==0?length-1:newer-1;
  const float sample=data[(size_t)newer];
  return sample+(delay-whole)*(data[(size_t)older]-sample);
 }
 void push(float x){data[(size_t)pos]=x;if(++pos==(int)data.size())pos=0;}
};
struct Biquad {
 float b0=1,b1=0,b2=0,a1=0,a2=0,z1=0,z2=0;
 void peak(float hz,float db,float q,float sr){float A=std::pow(10.f,db/40.f),w=2*pi*std::min(hz,sr*.4f)/sr,alpha=std::sin(w)/(2*q),c=std::cos(w),norm=1/(1+alpha/A);b0=(1+alpha*A)*norm;b1=-2*c*norm;b2=(1-alpha*A)*norm;a1=b1;a2=(1-alpha/A)*norm;}
 float tick(float x){float y=b0*x+z1;z1=b1*x-a1*y+z2;z2=b2*x-a2*y;return y;}
 void reset(){z1=z2=0;}
};
struct Effects {
 DelayLine chorus[2],delay[2],pre[2],comb[2][4],allpass[2][2];Biquad eq[2][7],tone[2][3];
 float damp[2][4]{},low[2]{},high[2]{},previous[2]{},dcIn[2]{},dcOut[2]{};
 float phase=0,verbPhase=0,fxPhase=0,envelope=0,reduction=0;
 float attack=.99f,release=.999f,compMakeup=1,distGain=1,toneGain=1;
 float on[5]={1,1,0,1,1};
 void prepare(float sr){for(int c=0;c<2;c++){
  chorus[c].prepare((int)(sr*.06f));delay[c].prepare((int)(sr*1.1f));pre[c].prepare((int)(sr*.4f));
  for(int k=0;k<4;k++)comb[c][k].prepare((int)(sr*.09f));
  allpass[c][0].prepare((int)(sr*.005f)+c*13);allpass[c][1].prepare((int)(sr*.0017f)+c*7);
 }reset();}
 void update(const Values& p,float sr){
  attack=std::exp(-1/(sr*p[CompAttack]*.001f));release=std::exp(-1/(sr*p[CompRelease]*.001f));compMakeup=std::pow(10.f,p[CompMakeup]/20.f);
  distGain=1+p[DistDrive]*24;toneGain=std::pow(10.f,p[DistLevel]/20.f);
  const float hz[]={100,200,400,800,1600,3200,6400};
  for(int c=0;c<2;c++){for(int k=0;k<7;k++)eq[c][k].peak(hz[k],p[(size_t)(Eq100+k)],p[EqWidth],sr);
   tone[c][0].peak(120,p[DistBass],.6f,sr);tone[c][1].peak(1000,p[DistMid],.7f,sr);tone[c][2].peak(6000,p[DistTreble],.6f,sr);}
 }
 void reset(){phase=verbPhase=fxPhase=envelope=reduction=0;for(int c=0;c<2;c++){chorus[c].reset();delay[c].reset();pre[c].reset();low[c]=high[c]=previous[c]=dcIn[c]=dcOut[c]=0;for(auto& b:eq[c])b.reset();for(auto& b:tone[c])b.reset();for(int k=0;k<4;k++){comb[c][k].reset();damp[c][k]=0;}for(auto& a:allpass[c])a.reset();}}
 float distort(float x,int mode)const{
  float d=x*distGain;
  if(mode==0)return std::tanh(d+.2f)-std::tanh(.2f);
  if(mode==1)return std::tanh(d*3.f)*(.7f+.3f*std::tanh(std::abs(d)*4.f));
  return d/(1+std::abs(d));
 }
 void tick(float& l,float& r,const Values& p,float sr,double bpm,float wheel){
  const Param switches[]={CompOn,EqOn,DistOn,EchoOn,VerbOn};for(int k=0;k<5;k++)on[k]+=(p[switches[k]]-on[k])*.002f;
  float peak=std::max(std::abs(l),std::abs(r)),coef=peak>envelope?attack:release;envelope=coef*envelope+(1-coef)*peak;
  float db=20*std::log10(std::max(1.e-8f,envelope));float gr=std::max(0.f,db-p[CompThreshold])*(1-1/p[CompRatio]);
  reduction=gr*on[0];float cg=std::pow(10.f,-gr/20.f)*compMakeup;float blend=p[CompMix]*on[0];l*=1+blend*(cg-1);r*=1+blend*(cg-1);
  phase+=.24f/sr;if(phase>=1)phase-=1;
  verbPhase+=p[VerbRate]/sr;if(verbPhase>=1)verbPhase-=1;
  fxPhase+=(p[FxSync]>.5f?(float)bpm/60.f:p[FxRate])/sr;if(fxPhase>=1)fxPhase-=std::floor(fxPhase);
  int shape=(int)p[FxShape];float mod=shape==0?std::sin(2*pi*fxPhase):(shape==1?1-4*std::abs(fxPhase-.5f):(fxPhase<.5f?1.f:-1.f));
  mod*=p[FxDepth]*(p[FxWheel]>.5f?wheel:1.f);
  float input[]={l,r},out[2]{};
  float echoMs=p[EchoSync]>.5f?(float)(45000.0/std::max(20.0,bpm)):p[DelayTime];echoMs=clamp(echoMs,40,1000);
  const float times[]={.0297f,.0371f,.0411f,.0437f};
  for(int c=0;c<2;c++){
   float x=input[c],equal=x;for(auto& b:eq[c])equal=b.tick(equal);x+=(equal-x)*on[1];
   float wetDist=(distort((x+previous[c])*.5f,(int)p[DistMode])+distort(x,(int)p[DistMode]))*.5f;previous[c]=x;
   float dc=wetDist-dcIn[c]+.995f*dcOut[c];dcIn[c]=wetDist;dcOut[c]=dc;
   for(auto& b:tone[c])dc=b.tick(dc);dc*=toneGain;x+=(dc-x)*p[DistMix]*on[2];
   float t=sr*(.018f+(.004f+.002f*mod)*std::sin(2*pi*(phase+c*.27f)));
   float ch=chorus[c].read(t);chorus[c].push(x);x=x*(1-.4f*p[Chorus])+ch*p[Chorus]*.65f;
   float wow=1+.003f*p[EchoWow]*std::sin(2*pi*(phase*.73f+c*.13f));float tapeTime=sr*.001f*echoMs*wow;
   float echo=delay[c].read(tapeTime);int heads=(int)p[EchoHeads];
   if(heads==1||heads==3)echo+=delay[c].read(tapeTime/3)*.65f;
   if(heads==2||heads==3)echo+=delay[c].read(tapeTime*2/3)*.65f;
   echo/=heads==3?2.3f:(heads==0?1.f:1.65f);
   float fb=clamp(p[Feedback]+mod*.1f,0,.9f);delay[c].push(std::tanh(x*on[3]+echo*fb));x+=echo*p[DelayMix]*on[3];
   high[c]+=(1-std::exp(-2*pi*p[VerbHigh]/sr))*(x-high[c]);float hp=x-high[c];
   low[c]+=(1-std::exp(-2*pi*p[VerbLow]/sr))*(hp-low[c]);pre[c].push(low[c]*on[4]);
   float preTime=sr*.001f*p[PreDelay];float feed=pre[c].read(std::max(1.f,preTime));
   float early=pre[c].read(preTime+sr*.017f)*.5f+pre[c].read(preTime+sr*.031f)*.3f;
   float wet=0;for(int k=0;k<4;k++){auto& d=comb[c][k];float sec=(times[k]+c*.0011f)*(.8f+.5f*p[Space]);float len=sr*sec;
    float modulation=sr*.00035f*p[VerbDepth]*std::sin(2*pi*(verbPhase+k*.23f+c*.17f));float y=d.read(len+modulation);
    damp[c][k]+=(.8f-.75f*p[VerbDamp])*(y-damp[c][k]);float decay=std::pow(.001f,sec/p[VerbDecay]);
    d.push(feed*.2f+damp[c][k]*decay);wet+=y*.25f;}
   for(auto& a:allpass[c]){float y=a.data[(size_t)a.pos];float z=y-wet*.5f;a.push(wet+y*.5f);wet=z;}
   float vm=clamp(p[Reverb]+mod*.08f,0,.8f)*on[4];out[c]=x*(1-.25f*vm)+(wet*1.7f+early*p[Early]) *vm;
  }l=out[0];r=out[1];
 }
};
inline double arpStepLength(double sampleRate,double bpm,int division){
 constexpr double beats[]={1.,.5,.25,1./3.,1./6.,4.,2.,4./3.};
 return sampleRate*60./std::max(5.,bpm)*beats[(size_t)division];
}
class Engine {
 float sr=48000,smoothCoeff=.001f,lfoPhase=0,lfoHeld=0;uint32_t rng=0x9e3779b9;uint64_t serial=0;
 Values current=defaults(),target=defaults();std::array<Voice,16> voices{};
 std::array<std::array<float,128>,16> held{},down{};std::array<bool,16> pedal{};
 std::array<float,16>bends{},mods{};Effects effects;
 bool arpWas=false,monoWas=false,arpHasNotes=false;
 int tailSamples=0,quietTailSamples=0;
 float limiterGain=1.f,limiterRecovery=.0003f,steadyAmount=0.f;double arpSamples=0,gateSamples=0;int arpStep=0;
 struct ArpNote{int note,channel;};
 std::array<ArpNote,16> soundingArp{};
 size_t soundingArpCount=0;
 float arpReleaseMs=8000.f;
 bool chordArp()const{return target[ArpOn]>.5f&&target[ArpChord]>.5f;}
 float random(){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return (float)(rng&0xffffff)/8388608.f-1;}
 void start(int note,int ch,float vel){
  Voice* selected=nullptr;
  if(monoWas)selected=&voices[0];
  else{for(auto& v:voices)if(!v.active()){selected=&v;break;}
   if(!selected)selected=&*std::min_element(voices.begin(),voices.end(),[](const Voice&a,const Voice&b){bool ar=a.amp.stage==Envelope::Release,br=b.amp.stage==Envelope::Release;return ar!=br?ar:a.age<b.age;});}
  const float velocity=clamp(vel,0.f,1.f);
  const int curve=(int)target[VelocityCurve];
  const float gain=curve==2?.85f*std::sqrt(velocity):curve==3?.70f:velocity;
  selected->start(note,ch,gain,++serial,monoWas&&target[Glide]>0,sr,current);
 }
 void releaseNote(int n,int ch,float maxMs=8000.f){for(auto& v:voices)if(v.note==n&&v.channel==ch)v.release(sr,current,maxMs);}
 void releaseAll(float maxMs=8000.f){for(auto& v:voices)v.release(sr,current,maxMs);soundingArpCount=0;}
 void releaseArp(){
  for(size_t i=0;i<soundingArpCount;++i)releaseNote(soundingArp[i].note,soundingArp[i].channel,arpReleaseMs);
  soundingArpCount=0;
 }
 bool anyHeld()const{for(const auto& channel:held)for(float v:channel)if(v>0)return true;return false;}
 void updateArpHeldNotes(){
  arpHasNotes=anyHeld();
  if(arpWas&&!arpHasNotes){releaseArp();arpSamples=gateSamples=0;arpStep=0;}
 }
 void releaseUnpressed(){for(int c=0;c<16;c++)if(chordArp()||!pedal[(size_t)c])for(int n=0;n<128;n++)if(held[(size_t)c][(size_t)n]>0&&down[(size_t)c][(size_t)n]==0){held[(size_t)c][(size_t)n]=0;if(!arpWas)releaseNote(n,c);}updateArpHeldNotes();}
 int collect(std::array<int,384>& notes,std::array<int,384>& chans,std::array<float,384>& velocities)const{
  int count=0;
  const int oct=(int)target[ArpOctaves],scale=(int)target[ArpScale],chord=(int)target[ArpChord];
  auto add=[&](int note,int ch,float velocity){
   if(note<=127&&count<(int)notes.size()){notes[(size_t)count]=note;chans[(size_t)count]=ch;velocities[(size_t)count]=velocity;++count;}
  };
  if(scale>0||chord>0){
   constexpr unsigned masks[]={
    0u,
    (1u<<0)|(1u<<2)|(1u<<4)|(1u<<5)|(1u<<7)|(1u<<9)|(1u<<11),
    (1u<<0)|(1u<<2)|(1u<<3)|(1u<<5)|(1u<<7)|(1u<<8)|(1u<<10),
    (1u<<0)|(1u<<2)|(1u<<3)|(1u<<5)|(1u<<7)|(1u<<8)|(1u<<11),
    (1u<<0)|(1u<<2)|(1u<<4)|(1u<<7)|(1u<<9),
    (1u<<0)|(1u<<3)|(1u<<5)|(1u<<7)|(1u<<10),
    0xfffu
   };
   constexpr unsigned chordMasks[]={
    0u,
    (1u<<0)|(1u<<4)|(1u<<7), // Major
    (1u<<0)|(1u<<3)|(1u<<7), // Minor
    (1u<<0)|(1u<<2)|(1u<<7), // Sus2
    (1u<<0)|(1u<<5)|(1u<<7), // Sus4
    (1u<<0)|(1u<<4)|(1u<<7)|(1u<<10), // Dominant seventh
    (1u<<0)|(1u<<4)|(1u<<7)|(1u<<11), // Major seventh
    (1u<<0)|(1u<<3)|(1u<<7)|(1u<<10) // Minor seventh
   };
   for(int n=0;n<128;n++)for(int c=0;c<16;c++)if(float v=held[(size_t)c][(size_t)n];v>0){
    const unsigned mask=chord>0?chordMasks[chord]:masks[scale];
    const int maxOffset=12*oct-(chord>0?1:0);
    for(int offset=0;offset<=maxOffset&&n+offset<=127;++offset)if(mask&(1u<<(offset%12)))add(n+offset,c,v);
    return count;
   }
   return 0;
  }
  for(int o=0;o<oct;o++)for(int n=0;n<128;n++)for(int c=0;c<16;c++)if(float v=held[(size_t)c][(size_t)n];v>0)add(n+12*o,c,v);
  return count;
 }
 void arpTick(double bpm){
  if(gateSamples>0&&--gateSamples<=0)releaseArp();
  if(--arpSamples>0)return;
  std::array<int,384> notes{},chans{};std::array<float,384> velocities{};int count=collect(notes,chans,velocities);if(count==0){arpSamples=0;return;}
  const double length=arpStepLength(sr,bpm,(int)target[ArpRate]);
  releaseArp();
  arpSamples+=length;gateSamples=length*target[ArpGate];
  // Keep chord release inside the gate gap so successive voicings do not merge.
  arpReleaseMs=chordArp()?std::min(40.f,(float)((length-gateSamples)*1000./sr)):8000.f;
  auto play=[&](size_t i){
   soundingArp[soundingArpCount++]={notes[i],chans[i]};
   start(notes[i],chans[i],target[VelocityCurve]<2.f?std::max(.1f,velocities[i]):velocities[i]);
  };
  if(target[ArpChord]>.5f){
   const auto chordSize=std::min(static_cast<size_t>(count),soundingArp.size());
   for(size_t i=0;i<chordSize;++i)play(i);
   return;
  }
  int mode=(int)target[ArpMode],index=arpStep%count;
  if(mode==1)index=count-1-index;
  else if(mode==2&&count>1){int p=arpStep%(2*count-2);index=p<count?p:2*count-2-p;}
  else if(mode==3)index=std::min(count-1,(int)((random()+1)*.5f*count));
  play((size_t)index);
  arpStep=(arpStep+1)%1000000;
 }
public:
 void prepare(double sampleRate){sr=(float)sampleRate;smoothCoeff=1-std::exp(-1.f/(sr*.015f));effects.prepare(sr);limiterRecovery=1.f-std::exp(-1.f/(sr*.065f));current=target;steadyAmount=target[HeldLevel];panic();}
 int currentArpNote(size_t index=0)const{return index<soundingArpCount?soundingArp[index].note:-1;}
 float gainReduction()const{return effects.reduction;}
 void setParameters(const Values& p,bool immediate=false){const bool wasHeld=target[ArpHold]>.5f;const bool wasChord=chordArp();const float previousScale=target[ArpScale],previousChord=target[ArpChord];for(size_t i=0;i<p.size();i++)target[i]=std::isfinite(p[i])?clamp(p[i],specs[i].lo,specs[i].hi):specs[i].initial;
  if(immediate){current=target;steadyAmount=target[HeldLevel];}
  effects.update(target,sr);
  if(wasHeld&&target[ArpHold]<.5f)releaseUnpressed();
  const bool arp=target[ArpOn]>.5f;
  const bool mono=target[Mono]>.5f&&!(arp&&target[ArpChord]>.5f);
  const bool changed=arp!=arpWas||mono!=monoWas||(arp&&(previousScale!=target[ArpScale]||previousChord!=target[ArpChord]));
  arpWas=arp;monoWas=mono;
  if(changed){
   const bool resetChord=wasChord||chordArp();
   releaseAll(resetChord?40.f:8000.f);
   arpStep=0;arpSamples=0;gateSamples=0;
   if(resetChord){
    // A new voicing must not inherit roots from an old latch or sustain pedal.
    held=down;
    updateArpHeldNotes();
   }
   if(!arp)for(int c=0;c<16;c++)for(int n=0;n<128;n++)if(held[(size_t)c][(size_t)n]>0)start(n,c,held[(size_t)c][(size_t)n]);
  }
 }
 void noteOn(int note,float velocity,int channel=0){if(note<0||note>127||channel<0||channel>15)return;
  if(velocity<=0){noteOff(note,channel);return;}
  if(target[ArpHold]>.5f){bool any=false;for(const auto& c:down)for(float v:c)any=any||v>0;if(!any)releaseUnpressed();}
  held[(size_t)channel][(size_t)note]=down[(size_t)channel][(size_t)note]=clamp(velocity,0,1);
  arpHasNotes=true;
  if(target[FxKeyReset]>.5f)effects.fxPhase=0;
  if(!arpWas)start(note,channel,velocity);
 }
 void noteOff(int note,int channel=0){if(note<0||note>127||channel<0||channel>15)return;down[(size_t)channel][(size_t)note]=0;
  if((!chordArp()&&pedal[(size_t)channel])||target[ArpHold]>.5f)return;
  held[(size_t)channel][(size_t)note]=0;updateArpHeldNotes();
  if(chordArp()&&soundingArpCount>0&&soundingArp[0].note==note&&soundingArp[0].channel==channel){
   releaseArp();arpSamples=gateSamples=0;
  }
  if(!arpWas){releaseNote(note,channel);if(monoWas&&voices[0].note==note){for(int n=127;n>=0;--n)if(held[(size_t)channel][(size_t)n]>0){start(n,channel,held[(size_t)channel][(size_t)n]);break;}}}
 }
 void controller(int number,int value,int ch=0){if(ch<0||ch>15)return;
  if(number==1)mods[(size_t)ch]=value/127.f;
  if(number==64){bool was=pedal[(size_t)ch];pedal[(size_t)ch]=value>=64;if(was&&value<64&&target[ArpHold]<.5f)releaseUnpressed();}
  if(number==120||number==123)panic();
 }
 void pitchWheel(int value,int ch=0){if(ch>=0&&ch<16)bends[(size_t)ch]=clamp((value-8192)/8192.f,-1,1);}
 void panic(){for(auto& v:voices){v.amp.reset();v.env.reset();v.filter.reset();v.note=-1;}for(auto& c:held)c.fill(0);for(auto& c:down)c.fill(0);pedal.fill(false);bends.fill(0);mods.fill(0);effects.reset();arpSamples=gateSamples=0;arpStep=0;soundingArpCount=0;arpHasNotes=false;tailSamples=quietTailSamples=0;limiterGain=1.f;}
 int activeVoices()const{int count=0;for(auto& v:voices)if(v.active())count++;return count;}
 void sample(float& left,float& right,double hostBpm=0){
  for(size_t i=0;i<current.size();i++){
   // Gate switches use a short gain ramp so toggling one cannot click.
   const bool oscillatorGate=i>=OscGate1&&i<=OscGate4;
   const bool discrete=specs[i].step==1&&specs[i].skew==1&&!oscillatorGate;
   current[i]=discrete?target[i]:current[i]+smoothCoeff*(target[i]-current[i]);
  }
  steadyAmount+=smoothCoeff*(target[HeldLevel]-steadyAmount);
  const float ampSustain=current[AmpS]+(1.f-current[AmpS])*steadyAmount;
  const float filterSustain=current[FilterS]+(1.f-current[FilterS])*steadyAmount;
  const bool validHost=std::isfinite(hostBpm)&&hostBpm>0;
  const double bpm=validHost?std::min(hostBpm,1000.0):target[Tempo];
  if(arpWas&&arpHasNotes)arpTick(target[ArpClock]<.5f?bpm:target[Tempo]);
  lfoPhase+=current[LfoRate]/sr;if(lfoPhase>=1){lfoPhase-=1;lfoHeld=random();}
  int shape=(int)target[LfoShape];float lfo=shape==0?std::sin(2*pi*lfoPhase):(shape==1?1-4*std::abs(lfoPhase-.5f):(shape==2?(lfoPhase<.5f?1.f:-1.f):lfoHeld));
  left=right=0;
  bool hasVoice=false;
  for(auto& v:voices){if(!v.active())continue;
   hasVoice=true;
   if(monoWas&&current[Glide]>0)v.pitch+=(v.note-v.pitch)*(1-std::exp(-1.f/(sr*.001f*std::max(1.f,current[Glide]))));else v.pitch=(float)v.note;
   float pitch=v.pitch+bends[(size_t)v.channel]*current[BendRange]+lfo*(current[LfoPitch]+mods[(size_t)v.channel]*.5f);
   float hz1=midiHz(pitch+12*target[Octave1]),hz2=midiHz(pitch+12*target[Octave2]+current[Detune]*.01f);
   const float rate1=hz1/sr,rate2=hz2/sr,subRate=rate1*.5f;
   const float rate3=midiHz(pitch+12*target[Octave3]+current[Detune3]*.01f)/sr;
   const float rate4=midiHz(pitch+12*target[Octave4]+current[Detune4]*.01f)/sr;
   // Mute above-band oscillators instead of pinning them to one piercing pitch.
   const auto tone=[](float phase,float rate,int shape,float pulse,float level){
    if(level<=0.f||rate>=.48f)return 0.f;
    return oscillator(phase,rate,shape,clamp(pulse,.05f,.95f))*level*bandGain(rate);
   };
   const float pwm=lfo*current[LfoPWM];
   float x=tone(v.phase1,rate1,(int)target[Wave1],current[Pulse1]+pwm,current[Level1]*current[OscGate1]);
   x+=tone(v.phase2,rate2,(int)target[Wave2],current[Pulse2]-pwm,current[Level2]*current[OscGate2]);
   x+=tone(v.phase3,rate3,(int)target[Wave3],current[Pulse3]+pwm,current[Level3]*current[OscGate3]);
   x+=tone(v.phase4,rate4,(int)target[Wave4],current[Pulse4]-pwm,current[Level4]*current[OscGate4]);
   x+=std::sin(2*pi*v.phaseSub)*current[Sub]*bandGain(subRate)+random()*current[Noise];
   const auto advance=[](float& phase,float rate){
    phase+=rate;
    phase-=std::floor(phase);
   };
   advance(v.phase1,rate1);advance(v.phase2,rate2);advance(v.phase3,rate3);
   advance(v.phase4,rate4);advance(v.phaseSub,subRate);
   float e=v.env.tick(current[FilterA],current[FilterD],filterSustain,sr);
   float cutoff=current[Cutoff]*std::exp2(e*current[EnvAmount]+lfo*current[LfoFilter]+current[KeyTrack]*(v.note-60)/12.f);
   x=std::tanh(x*(1+current[Drive]*5))*.5f;x=v.filter.tick(x,cutoff,current[Resonance],(int)target[FilterMode],sr);
   x*=v.amp.tick(current[AmpA],current[AmpD],ampSustain,sr)*v.velocity*(1-current[LfoAmp]*(.5f+.5f*lfo))*.22f;
   float pan=v.pan;left+=x*std::sqrt(.5f-pan*.8f);right+=x*std::sqrt(.5f+pan*.8f);
  }
  if(hasVoice){tailSamples=(int)(sr*20.f);quietTailSamples=0;}
  else if(tailSamples==0)return;
  float wheel=0;for(float m:mods)wheel=std::max(wheel,m);
  effects.tick(left,right,current,sr,bpm,wheel);
  const float gain=std::pow(10.f,current[Master]/20.f);
  left*=gain;right*=gain;
  if(!std::isfinite(left)||!std::isfinite(right)){panic();left=right=0;return;}
  // Catch peaks on the first sample and recover gradually with the same gain on both channels.
  const float peak=std::max(std::abs(left),std::abs(right));
  const float peakGain=peak>outputPeakCeiling?outputPeakCeiling/peak:1.f;
  limiterGain=std::min(peakGain,limiterGain+(1.f-limiterGain)*limiterRecovery);
  left*=limiterGain;right*=limiterGain;
  if(!hasVoice){
   // Wait through the longest echo interval before clearing an inaudible tail.
   quietTailSamples=std::max(std::abs(left),std::abs(right))<1.e-5f?quietTailSamples+1:0;
   if(--tailSamples==0||quietTailSamples>=(int)(sr*2.f)){
    tailSamples=quietTailSamples=0;effects.reset();left=right=0;
   }
  }
 }
};
}
