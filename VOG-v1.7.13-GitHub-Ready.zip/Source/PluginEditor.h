#pragma once
#include "PluginProcessor.h"
#include "UserPatches.h"
namespace davoeui {
inline const juce::Colour bg{0xff391522},cream{0xffeee4be},muted{0xffadad99},red{0xffd56b53},green{0xff8cae79};
class Theme:public juce::LookAndFeel_V4 {
public:Theme();void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&)override;
};
struct Control:juce::Component {
 juce::Label label;juce::Slider knob;juce::ComboBox choice;
 std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> sa;
 std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> ca;
 bool labelBesideBox;
 Control(juce::AudioProcessorValueTreeState&,davoe::Param,bool compactLabel=false);void resized()override;
};
struct Panel:juce::Component {
 juce::String title,subtitle;juce::Colour accent;int columns;std::vector<std::unique_ptr<Control>> controls;
 juce::TextButton randomScale{"RANDOM SCALE"};
 std::unique_ptr<juce::TextButton> oscillatorGate;
 std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> gateAttachment;
 Panel(juce::AudioProcessorValueTreeState&,juce::String,juce::String,juce::Colour,int,
       std::initializer_list<davoe::Param>,davoe::Param gate=davoe::ParamCount);
 void paint(juce::Graphics&)override;void resized()override;
};
struct EQPanel:juce::Component {
 juce::Label heading;std::array<juce::Slider,7> faders;std::array<juce::Label,7> labels;
 std::array<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>,7> attachments;
 std::unique_ptr<Control> on,width;
 explicit EQPanel(juce::AudioProcessorValueTreeState&);void paint(juce::Graphics&)override;void resized()override;
};
}
class DavoeSynthEditor final:public juce::AudioProcessorEditor,private juce::Timer {
public:explicit DavoeSynthEditor(DavoeSynthProcessor&);~DavoeSynthEditor()override;void paint(juce::Graphics&)override;void resized()override;
private:
 DavoeSynthProcessor& processor;davoeui::Theme theme;
 struct Surface final:juce::Component {
  explicit Surface(DavoeSynthEditor& editor):owner(editor){}
  void paint(juce::Graphics& g)override{owner.paintSurface(g);}
  DavoeSynthEditor& owner;
 };
 Surface surface{*this};
 juce::ComboBox zoomMenu;
 static constexpr std::array<int,9> zoomLevels{60,70,75,85,90,100,110,125,150};
 int zoomPercent=100;
 int defaultZoom()const;
 void fitToScreen(int preferredZoom);
 void applyZoom(int percent,int logicalWidth,int logicalHeight);
 void paintSurface(juce::Graphics&);
 juce::Component canvas,synthPage,effectsPage;juce::Viewport view;
 std::vector<std::unique_ptr<davoeui::Panel>> synthPanels,effectPanels;
 std::unique_ptr<davoeui::EQPanel> equalizer;
 juce::MidiKeyboardComponent keyboard;
 juce::ComboBox presets,category;juce::TextEditor search;juce::TextButton previous{"<"},next{">"};std::vector<int> visiblePrograms;juce::TextButton synthTab{"SYNTHESIZER"},effectsTab{"EFFECTS RACK"},panic{"PANIC"},save{"SAVE PATCH"},load{"PATCH FILES"};
 juce::TextButton record{"REC"},saveWav{"SAVE WAV"},fit{"FIT"};juce::String recordingNotice;
 davoe::UserPatches library=davoe::UserPatches::forCurrentUser();juce::StringArray userPatches;
 struct PatchPrompt final:juce::Component{
  void paint(juce::Graphics& g)override{
   auto bounds=getLocalBounds().toFloat().reduced(1.f);
   g.setColour(davoeui::bg);g.fillRoundedRectangle(bounds,6.f);
   g.setColour(davoeui::red);g.drawRoundedRectangle(bounds,6.f,1.5f);
  }
 } patchPrompt;
 juce::TextEditor patchName;
 juce::Label patchPromptStatus;
 juce::TextButton confirmPatch{"SAVE"},cancelPatch{"CANCEL"};
 juce::String patchNotice;
 void saveNamedPatch();
 void closePatchPrompt();
 juce::Label status;juce::Slider pitchWheel,modWheel;juce::Label pitchLabel,modLabel;
 juce::TooltipWindow tooltips{this,600};std::unique_ptr<juce::FileChooser> chooser;
 bool rack=false;unsigned int selectedRevision=0;void showRack(bool);void rebuildPresets();void refreshUserPatches();int activePreset()const;void selectPreset(int);void promptForPatchName();void patchFileMenu();void choosePatchFile(bool);void browse(int);void timerCallback()override;
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DavoeSynthEditor)
};
