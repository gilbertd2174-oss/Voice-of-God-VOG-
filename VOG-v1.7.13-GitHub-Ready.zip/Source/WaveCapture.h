#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace davoe {
// The processor owns the lock. Allocation and file writes stay off the audio thread.
class WaveCapture {
 std::vector<std::uint8_t> bytes;
 std::uint32_t rate=0,frames=0,capacity=0;
 bool recording=false,normalized=false;
 void word(std::size_t at,std::uint32_t value,int length){
  for(int i=0;i<length;++i)bytes[at+(std::size_t)i]=(std::uint8_t)(value>>(8*i));
 }
 static std::uint16_t pcm(float x){
  if(!std::isfinite(x))x=0;
  x=std::max(-1.f,std::min(1.f,x));
  return (std::uint16_t)(std::int16_t)std::lround(x*(x<0?32768.f:32767.f));
 }
 int sampleAt(std::size_t at)const{
  const int sample=(int)bytes[at]|((int)bytes[at+1]<<8);
  return sample>=32768?sample-65536:sample;
 }
 void normalizeRecording(){
  if(normalized)return;
  normalized=true;
  int peak=0;
  for(std::size_t at=44;at<size();at+=2)peak=std::max(peak,std::abs(sampleAt(at)));
  if(peak==0)return;
  // Use one gain for the stereo take and limit the boost on very quiet recordings.
  constexpr double ceiling=29204.0; // Approximately -1 dBFS.
  const double gain=std::min(16.0,ceiling/peak);
  for(std::size_t at=44;at<size();at+=2){
   const auto sample=(std::int16_t)std::lround(sampleAt(at)*gain);
   word(at,(std::uint16_t)sample,2);
  }
 }
public:
 static constexpr int maxSeconds=180;
 static bool supportsRate(std::uint32_t hz){return hz>=8000&&hz<=192000;}
 bool begin(std::uint32_t hz){
  if(!supportsRate(hz))return false;
  const auto count=hz*maxSeconds;
  std::vector<std::uint8_t> storage(44+(std::size_t)count*4);
  bytes.swap(storage);rate=hz;frames=0;capacity=count;recording=true;normalized=false;
  return true;
 }
 void stop(){recording=false;}
 bool active()const{return recording;}
 std::uint32_t frameCount()const{return frames;}
 double seconds()const{return rate?(double)frames/rate:0.;}
 void append(const float* l,const float* r,int count){
  if(!recording||count<=0)return;
  const auto size=std::min((std::uint32_t)count,capacity-frames);
  for(std::uint32_t i=0;i<size;++i){const auto at=44+(std::size_t)(frames+i)*4;word(at,pcm(l[i]),2);word(at+2,pcm(r[i]),2);}
  frames+=size;if(frames==capacity)stop();
 }
 bool finishHeader(bool boost=false){
  if(recording||frames==0)return false;
  if(boost)normalizeRecording();
  const auto tag=[this](std::size_t at,const char* s){for(int i=0;i<4;i++)bytes[at+(std::size_t)i]=(std::uint8_t)s[i];};
  tag(0,"RIFF");word(4,36+frames*4,4);tag(8,"WAVE");tag(12,"fmt ");word(16,16,4);
  word(20,1,2);word(22,2,2);word(24,rate,4);word(28,rate*4,4);word(32,4,2);word(34,16,2);
  tag(36,"data");word(40,frames*4,4);return true;
 }
 const std::uint8_t* data()const{return bytes.data();}
 std::size_t size()const{return 44+(std::size_t)frames*4;}
};
}
