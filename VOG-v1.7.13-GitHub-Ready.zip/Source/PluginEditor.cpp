#include "PluginEditor.h"
namespace davoeui {
static const juce::Colour buttonFill{0xff471f2c};
static juce::Font controlLabelFont(float size){return juce::Font(juce::FontOptions(size,juce::Font::bold));}
static juce::Font headingFont(float size){return juce::Font(juce::FontOptions("Bahnschrift","SemiBold",size));}
Theme::Theme(){setColour(juce::ResizableWindow::backgroundColourId,bg);setColour(juce::Label::textColourId,cream);setColour(juce::Slider::textBoxTextColourId,juce::Colour(0xff171a16));setColour(juce::Slider::textBoxBackgroundColourId,juce::Colour(0xffe6dec8));setColour(juce::Slider::textBoxOutlineColourId,juce::Colour(0xff4b514b));setColour(juce::ComboBox::backgroundColourId,juce::Colour(0xff101616));setColour(juce::ComboBox::textColourId,cream);setColour(juce::ComboBox::outlineColourId,juce::Colour(0xff666b5c));setColour(juce::PopupMenu::backgroundColourId,bg);setColour(juce::PopupMenu::textColourId,cream);setColour(juce::TextButton::buttonColourId,buttonFill);setColour(juce::TextButton::textColourOffId,cream);setColour(juce::Slider::thumbColourId,cream);setColour(juce::Slider::trackColourId,green);}
void Theme::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float start,float end,juce::Slider&){
 const float size=juce::jmax(8.f,(float)juce::jmin(w,h)-16.f);
 const auto rim=juce::Rectangle<float>((float)x+((float)w-size)*.5f,(float)y+((float)h-size)*.5f,size,size);
 const auto centre=rim.getCentre();
 const float radius=size*.5f,angle=start+pos*(end-start);
 const auto point=[centre](float a,float distance){
  return juce::Point<float>(centre.x+std::sin(a)*distance,centre.y-std::cos(a)*distance);
 };
 const auto drawMark=[&](float a,float from,float to,float thickness){
  const auto p=point(a,from),q=point(a,to);
  g.drawLine(p.x,p.y,q.x,q.y,thickness);
 };

 // Panel shadow and engraved scale.
 for(int i=3;i>=0;--i){
  g.setColour(juce::Colours::black.withAlpha(.14f+i*.025f));
  g.fillEllipse(rim.translated(1.3f,3.4f).expanded((float)i));
 }
 for(int i=0;i<=10;++i){
  const float a=start+(end-start)*i/10.f;
  g.setColour(i<=pos*10?cream:juce::Colour(0xff636659));
  drawMark(a,radius+3.f,radius+(i%5==0?6.f:5.f),1.f);
 }

 // A thin metal rim surrounds the navy grip and raised cap.
 juce::ColourGradient metal(juce::Colour(0xffc9c9c9),rim.getTopLeft(),
                            juce::Colour(0xff343434),rim.getBottomRight(),false);
 metal.addColour(.46,juce::Colour(0xff757575));
 g.setGradientFill(metal);g.fillEllipse(rim);
 g.setColour(juce::Colour(0xff171717));g.drawEllipse(rim,.65f);

 const float rimWidth=juce::jmin(2.f,radius*.23f);
 const auto grip=rim.reduced(rimWidth);
 g.setGradientFill(juce::ColourGradient(juce::Colour(0xff38517a),grip.getTopLeft(),
                                      juce::Colour(0xff060d1c),grip.getBottomRight(),false));
 g.fillEllipse(grip);
 const float gripRadius=grip.getWidth()*.5f,capRadius=gripRadius*.79f;
 if(radius>=10.f){
  for(int i=0;i<32;++i){
   const float a=angle+2.f*davoe::pi*i/32.f;
   g.setColour(juce::Colours::black.withAlpha(.46f));
   drawMark(a,capRadius,gripRadius-.55f,1.f);
   g.setColour(juce::Colour(0xff8ba7d4).withAlpha(.29f));
   drawMark(a+.032f,capRadius,gripRadius-.8f,.65f);
  }
 }

 const auto cap=juce::Rectangle<float>(2.f*capRadius,2.f*capRadius).withCentre(centre);
 juce::ColourGradient enamel(juce::Colour(0xff4a6792),point(-.65f,capRadius*.76f),
                              juce::Colour(0xff0a162c),point(2.25f,capRadius*1.2f),true);
 enamel.addColour(.55,juce::Colour(0xff1c3155));
 g.setGradientFill(enamel);g.fillEllipse(cap);
 g.setColour(juce::Colour(0xff080f20));g.drawEllipse(cap,.8f);
 g.setColour(juce::Colour(0xff9eb2cf).withAlpha(.30f));g.drawEllipse(cap.reduced(1.f),.55f);

 const float slotWidth=juce::jlimit(1.2f,3.6f,capRadius*.19f);
 g.setColour(juce::Colour(0xff040811));drawMark(angle,capRadius*.29f,capRadius*.94f,slotWidth+1.3f);
 g.setColour(juce::Colour(0xffffd783));drawMark(angle,capRadius*.36f,capRadius*.88f,slotWidth);
}
Control::Control(juce::AudioProcessorValueTreeState& state,davoe::Param id,bool compactLabel):labelBesideBox(compactLabel){auto& spec=davoe::specs[(size_t)id];addAndMakeVisible(label);label.setText(spec.name,juce::dontSendNotification);label.setJustificationType(juce::Justification::centred);label.setFont(controlLabelFont(13.f));label.setTooltip(spec.help);
 if(spec.choices[0]){addAndMakeVisible(choice);auto strings=juce::StringArray::fromTokens(spec.choices,"|","");choice.addItemList(strings,1);choice.setTooltip(spec.help);ca=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(state,spec.id,choice);}
 else{addAndMakeVisible(knob);knob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);knob.setTextBoxStyle(juce::Slider::TextBoxBelow,false,78,20);knob.setDoubleClickReturnValue(true,spec.initial);knob.setTooltip(spec.help);knob.setName(spec.name);sa=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(state,spec.id,knob);
  if(id==davoe::ArpGate){
   knob.textFromValueFunction=[](double value){return juce::String(juce::roundToInt(value*100.0))+"%";};
   knob.valueFromTextFunction=[](const juce::String& text){return text.getDoubleValue()/100.0;};
   knob.updateText();
  }
 }
}
void Control::resized(){auto r=getLocalBounds();label.setBounds(r.removeFromTop(22));if(ca){auto box=r.reduced(5,juce::jmax(2,(r.getHeight()-30)/2));choice.setBounds(box);if(labelBesideBox)label.setBounds(0,juce::jmax(0,box.getY()-24),getWidth(),22);}else knob.setBounds(r.reduced(4,1));}
Panel::Panel(juce::AudioProcessorValueTreeState& state,juce::String name,juce::String sub,juce::Colour col,int cols,std::initializer_list<davoe::Param> ids,davoe::Param gate):title(name),subtitle(sub),accent(col),columns(cols){for(auto id:ids){auto c=std::make_unique<Control>(state,id,title=="ARPEGGIATOR");addAndMakeVisible(*c);controls.push_back(std::move(c));}
 if(gate!=davoe::ParamCount){
  const auto& spec=davoe::specs[(size_t)gate];
  oscillatorGate=std::make_unique<juce::TextButton>("GATE ON");
  oscillatorGate->setTitle(spec.name);
  oscillatorGate->setTooltip(spec.help);
  oscillatorGate->setClickingTogglesState(true);
  oscillatorGate->setColour(juce::TextButton::buttonOnColourId,juce::Colour(0xff455738));
  oscillatorGate->setColour(juce::TextButton::textColourOnId,cream);
  oscillatorGate->onStateChange=[this]{
   oscillatorGate->setButtonText(oscillatorGate->getToggleState()?"GATE ON":"GATE OFF");
  };
  addAndMakeVisible(*oscillatorGate);
  gateAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(state,spec.id,*oscillatorGate);
  oscillatorGate->setButtonText(oscillatorGate->getToggleState()?"GATE ON":"GATE OFF");
 }
 if(title=="ARPEGGIATOR"){
  addAndMakeVisible(randomScale);
  randomScale.setTooltip("Pick a different scale and switch Chord off");
  auto* scale=state.getParameter(davoe::specs[davoe::ArpScale].id);
  auto* chord=state.getParameter(davoe::specs[davoe::ArpChord].id);
  randomScale.onClick=[scale,chord]{
   if(scale==nullptr||chord==nullptr)return;
   const int count=(int)davoe::specs[davoe::ArpScale].hi;
   const int selected=juce::roundToInt(scale->convertFrom0to1(scale->getValue()));
   int next=1+juce::Random::getSystemRandom().nextInt(count-(selected>0?1:0));
   if(selected>0&&next>=selected)++next;
   chord->beginChangeGesture();chord->setValueNotifyingHost(chord->convertTo0to1(0.f));chord->endChangeGesture();
   scale->beginChangeGesture();scale->setValueNotifyingHost(scale->convertTo0to1((float)next));scale->endChangeGesture();
  };
 }
}
void Panel::paint(juce::Graphics& g){auto r=getLocalBounds().toFloat().reduced(1);g.setGradientFill(juce::ColourGradient(juce::Colour(0xff242526),r.getTopLeft(),juce::Colour(0xff111214),r.getBottomRight(),false));g.fillRoundedRectangle(r,8);g.setColour(juce::Colour(0xff781d28));g.drawRoundedRectangle(r,8,2.f);g.setColour(cream);g.setFont(headingFont(17.f));g.drawText(title,14,9,getWidth()-(oscillatorGate?94:28),22,juce::Justification::centredLeft);g.setColour(muted);g.setFont(11.f);if(title=="ARPEGGIATOR")g.drawText(subtitle,280,10,getWidth()-302,20,juce::Justification::centredRight);else g.drawText(subtitle,14,31,getWidth()-28,16,juce::Justification::centredLeft);if(title.contains("COMPRESSOR")){auto meter=juce::Rectangle<float>((float)getWidth()-126,9,108,32);g.setColour(juce::Colour(0xffd9ca91));g.fillRoundedRectangle(meter,3);g.setColour(juce::Colour(0xff413c26));g.setFont(9.f);g.drawText("GAIN REDUCTION",meter.toNearestInt().withTrimmedTop(19),juce::Justification::centred);float gr=(float)getProperties().getWithDefault("gr",0.f);float a=-.9f+juce::jlimit(0.f,1.f,gr/24.f)*1.8f;g.setColour(red);g.drawLine(meter.getCentreX(),meter.getBottom()-9,meter.getCentreX()+std::sin(a)*28,meter.getBottom()-9-std::cos(a)*21,1.7f);}
 for(int x:{8,getWidth()-12}){g.setColour(juce::Colour(0xff7b8275));g.fillEllipse((float)x,8,4,4);g.setColour(juce::Colours::black);g.drawLine((float)x,10,(float)x+4,10,1);}}
void Panel::resized(){auto r=getLocalBounds().reduced(8);r.removeFromTop(43);
 if(oscillatorGate)oscillatorGate->setBounds(getWidth()-73,7,60,22);
 if(title=="ARPEGGIATOR"&&controls.size()==10){
  randomScale.setBounds(154,7,118,22);
  r=getLocalBounds().reduced(8,5);r.removeFromTop(28);
  auto place=[&](juce::Rectangle<int> area,std::initializer_list<int> indices){
   int slot=0,count=(int)indices.size();
   for(int index:indices){
    const int a=slot*area.getWidth()/count,b=(slot+1)*area.getWidth()/count;
    controls[(size_t)index]->setBounds(area.getX()+a,area.getY(),b-a,area.getHeight());
    ++slot;
   }
  };
  if(getWidth()<950){
   auto knobs=r.removeFromTop(r.getHeight()-58);
   knobs.setWidth(knobs.getWidth()*2/3);knobs.setX((getWidth()-knobs.getWidth())/2);
   place(knobs,{4,5,6});place(r,{0,1,2,3,7,8,9});
  }else{
   const int side=r.getWidth()/3;
   const auto left=r.removeFromLeft(side),right=r.removeFromRight(side);
   place(left,{0,1,8});place(r,{4,5,6});place(right,{2,3,7,9});
  }
  return;
 }
 int rows=((int)controls.size()+columns-1)/columns;for(size_t i=0;i<controls.size();i++){int col=(int)i%columns,row=(int)i/columns;int w=r.getWidth()/columns,h=r.getHeight()/rows;controls[i]->setBounds(r.getX()+col*w,r.getY()+row*h,w,h);}}
EQPanel::EQPanel(juce::AudioProcessorValueTreeState& state){on=std::make_unique<Control>(state,davoe::EqOn);width=std::make_unique<Control>(state,davoe::EqWidth);addAndMakeVisible(*on);addAndMakeVisible(*width);for(size_t i=0;i<7;i++){auto& s=davoe::specs[(size_t)davoe::Eq100+i];auto& f=faders[i];addAndMakeVisible(f);f.setSliderStyle(juce::Slider::LinearVertical);f.setTextBoxStyle(juce::Slider::TextBoxBelow,false,54,20);f.setDoubleClickReturnValue(true,0);f.setTooltip(s.help);attachments[i]=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(state,s.id,f);addAndMakeVisible(labels[i]);labels[i].setText(s.name,juce::dontSendNotification);labels[i].setJustificationType(juce::Justification::centred);labels[i].setFont(12.f);}}
void EQPanel::paint(juce::Graphics& g){g.setColour(juce::Colour(0xff17181a));g.fillRoundedRectangle(getLocalBounds().toFloat().reduced(1),8);g.setColour(juce::Colour(0xff781d28));g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(1),8,1.2f);g.setColour(cream);g.setFont(headingFont(17.f));g.drawText("SEVEN-BAND EQUALIZER",14,10,getWidth()-28,24,juce::Justification::centredLeft);g.setColour(muted);g.setFont(11.f);g.drawText("±15 dB • Double-click a fader to reset",14,34,getWidth()-28,16,juce::Justification::centredLeft);g.setColour(cream.withAlpha(.12f));g.drawHorizontalLine(155,12.f,(float)getWidth()-12);}
void EQPanel::resized(){int w=(getWidth()-18)/7;for(int i=0;i<7;i++){labels[(size_t)i].setBounds(9+i*w,55,w,21);faders[(size_t)i].setBounds(9+i*w,80,w,168);}on->setBounds(8,260,getWidth()/2-12,88);width->setBounds(getWidth()/2,250,getWidth()/2-8,104);}
}
DavoeSynthEditor::DavoeSynthEditor(DavoeSynthProcessor& p):AudioProcessorEditor(p),processor(p),keyboard(p.keyboard,juce::MidiKeyboardComponent::horizontalKeyboard){
 using namespace davoe;using namespace davoeui;setLookAndFeel(&theme);setResizable(true,true);
 addAndMakeVisible(surface);surface.addAndMakeVisible(view);view.setViewedComponent(&canvas,false);view.setScrollBarsShown(true,false);canvas.addAndMakeVisible(synthPage);canvas.addChildComponent(effectsPage);
 auto panel=[&](juce::Component& page,std::vector<std::unique_ptr<Panel>>& list,const char* title,const char* sub,juce::Colour c,int cols,std::initializer_list<Param> ids,Param gate=ParamCount){auto x=std::make_unique<Panel>(p.state,title,sub,c,cols,ids,gate);page.addAndMakeVisible(*x);list.push_back(std::move(x));};
 panel(synthPage,synthPanels,"OSCILLATOR 1","Band-limited • analog waveforms",red,2,{Wave1,Octave1,Level1,Pulse1},OscGate1);
 panel(synthPage,synthPanels,"OSCILLATOR 2","Independent pitch • fine detuning",red,2,{Wave2,Octave2,Level2,Detune,Pulse2},OscGate2);
 panel(synthPage,synthPanels,"OSCILLATOR 3","Independent wave • octave • fine tune",red,2,{Wave3,Octave3,Level3,Detune3,Pulse3},OscGate3);
 panel(synthPage,synthPanels,"OSCILLATOR 4","Independent wave • octave • fine tune",red,2,{Wave4,Octave4,Level4,Detune4,Pulse4},OscGate4);
 panel(synthPage,synthPanels,"SOURCE MIXER","Sub • noise • warmth • width",cream,2,{Sub,Noise,Drive,Spread});
 panel(synthPage,synthPanels,"RESONANT FILTER","Low pass • high pass • band pass",green,2,{FilterMode,Cutoff,Resonance,EnvAmount,KeyTrack});
 panel(synthPage,synthPanels,"AMPLITUDE","ADSR • velocity sensitive",red,2,{AmpA,AmpD,AmpS,AmpR});
 panel(synthPage,synthPanels,"FILTER ENVELOPE","Independent ADSR contour",green,2,{FilterA,FilterD,FilterS,FilterR});
 panel(synthPage,synthPanels,"LOW FREQUENCY OSCILLATOR","Pitch • filter • PWM • tremolo",red,3,{LfoShape,LfoRate,LfoPitch,LfoFilter,LfoPWM,LfoAmp});
 panel(synthPage,synthPanels,"ARPEGGIATOR","Hold • DAW or internal clock • 5–240 BPM",cream,4,{ArpOn,ArpMode,ArpRate,ArpHold,ArpOctaves,ArpGate,Tempo,ArpClock,ArpScale,ArpChord});
 panel(synthPage,synthPanels,"SPACE & MOTION","Full controls on the effects page",green,3,{Chorus,DelayMix,DelayTime,Feedback,Reverb,Space});
 panel(synthPage,synthPanels,"PERFORMANCE","Keyboard response • output",cream,2,{VelocityCurve,HeldLevel,Mono,Glide,BendRange,Master});
 panel(effectsPage,effectPanels,"DYNAMICS / COMPRESSOR","Stereo linked • parallel compression",red,4,{CompOn,CompThreshold,CompRatio,CompAttack,CompRelease,CompMakeup,CompMix});
 equalizer=std::make_unique<EQPanel>(p.state);effectsPage.addAndMakeVisible(*equalizer);
 panel(effectsPage,effectPanels,"DISTORTION & TONE","Tube • fuzz • saturation",red,4,{DistOn,DistMode,DistDrive,DistBass,DistMid,DistTreble,DistLevel,DistMix});
 panel(effectsPage,effectPanels,"MULTI-HEAD TAPE ECHO","Three heads • wow/flutter • tempo sync",green,4,{EchoOn,EchoHeads,EchoSync,DelayTime,Feedback,DelayMix,EchoWow});
 panel(effectsPage,effectPanels,"LUSH REVERB","Pre-delay • early reflections • modulation",juce::Colour(0xffada0ca),4,{VerbOn,Reverb,PreDelay,Early,Space,VerbDecay,VerbDamp,VerbHigh,VerbLow,VerbRate,VerbDepth});
 panel(effectsPage,effectPanels,"EFFECTS MODULATOR","Echo feedback • room mix • chorus",cream,4,{FxRate,FxShape,FxDepth,FxSync,FxWheel,FxKeyReset,Chorus});
 for(auto* c:std::initializer_list<juce::Component*>{&previous,&next,&search,&category,&presets,&synthTab,&effectsTab,&panic,&save,&load,&record,&saveWav,&fit,&zoomMenu,&keyboard,&status,&pitchWheel,&modWheel,&pitchLabel,&modLabel})surface.addAndMakeVisible(*c);
 category.addItemList({"All sounds","Essentials","Bass","Leads","Pads & strings","Keys & plucks","Arps","Textures","User Patches","New 100"},1);
 category.setSelectedId(1,juce::dontSendNotification);category.onChange=[this]{refreshUserPatches();};
 search.setMultiLine(false);search.setTextToShowWhenEmpty("Find a preset...",muted);search.setColour(juce::TextEditor::backgroundColourId,juce::Colour(0xff101616));search.setColour(juce::TextEditor::textColourId,cream);search.onTextChange=[this]{rebuildPresets();};
 previous.setTooltip("Previous matching preset");next.setTooltip("Next matching preset");
 previous.onClick=[this]{browse(-1);};next.onClick=[this]{browse(1);};
 search.onReturnKey=[this]{if(visiblePrograms.size()==1)selectPreset(visiblePrograms.front());};
 search.onEscapeKey=[this]{search.clear();keyboard.grabKeyboardFocus();};
 presets.onChange=[this]{if(presets.getSelectedId()>0)selectPreset(presets.getSelectedId()-1);};
 refreshUserPatches();
 for(auto* button:{&synthTab,&effectsTab,&save,&load}){
  button->setColour(juce::TextButton::buttonColourId,buttonFill);
  button->setColour(juce::TextButton::buttonOnColourId,buttonFill);
  button->setColour(juce::TextButton::textColourOnId,cream);
 }
 synthTab.onClick=[this]{showRack(false);};effectsTab.onClick=[this]{showRack(true);};panic.onClick=[this]{processor.panicRequested.store(true);};panic.setTooltip("Stop all voices, clear latched notes and effect tails");
 const juce::Component::SafePointer<DavoeSynthEditor> editorGuard(this);
 record.setColour(juce::TextButton::buttonOnColourId,juce::Colour(0xff942837));
 record.setTooltip("Record this synth in stereo for up to three minutes. Starting a take replaces the previous take.");
 saveWav.setTooltip("Save the stopped take as a louder, peak-normalized 16-bit stereo WAV");
 record.onClick=[this]{recordingNotice.clear();if(processor.recording.load())processor.stopRecording();else{auto result=processor.startRecording();if(result.failed())recordingNotice=result.getErrorMessage();}};
 saveWav.onClick=[this,editorGuard]{
  chooser=std::make_unique<juce::FileChooser>("Save VOG recording",juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("VOG Recording.wav"),"*.wav");
  chooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting,[safe=editorGuard](const juce::FileChooser& c){if(safe&&c.getResult()!=juce::File()){auto result=safe->processor.saveRecording(c.getResult());safe->recordingNotice=result.wasOk()?"WAV saved":result.getErrorMessage();}});
 };

 surface.addChildComponent(patchPrompt);
 patchPrompt.setAlwaysOnTop(true);
 for(auto* child:std::initializer_list<juce::Component*>{&patchName,&patchPromptStatus,&confirmPatch,&cancelPatch})patchPrompt.addAndMakeVisible(*child);
 patchName.setMultiLine(false);
 patchName.setTextToShowWhenEmpty("Patch name",muted);
 patchName.onReturnKey=[this]{saveNamedPatch();};
 patchName.onEscapeKey=[this]{closePatchPrompt();};
 confirmPatch.onClick=[this]{saveNamedPatch();};
 cancelPatch.onClick=[this]{closePatchPrompt();};
 patchPromptStatus.setJustificationType(juce::Justification::centredLeft);
 save.onClick=[this]{promptForPatchName();};
 load.onClick=[this]{patchFileMenu();};
 load.setTooltip("Import or export a .vog file");
 keyboard.setAvailableRange(36,107);keyboard.setLowestVisibleKey(36);keyboard.setScrollButtonsVisible(false);keyboard.setColour(juce::MidiKeyboardComponent::whiteNoteColourId,juce::Colour(0xffe7e0cc));keyboard.setColour(juce::MidiKeyboardComponent::blackNoteColourId,juce::Colour(0xff101514));keyboard.setColour(juce::MidiKeyboardComponent::keyDownOverlayColourId,red.withAlpha(.65f));keyboard.setWantsKeyboardFocus(true);
 pitchLabel.setText("PITCH",juce::dontSendNotification);modLabel.setText("MOD",juce::dontSendNotification);pitchLabel.setJustificationType(juce::Justification::centred);modLabel.setJustificationType(juce::Justification::centred);
 pitchWheel.setSliderStyle(juce::Slider::LinearVertical);pitchWheel.setTextBoxStyle(juce::Slider::NoTextBox,false,0,0);pitchWheel.setRange(0,16383,1);pitchWheel.setValue(8192);pitchWheel.setDoubleClickReturnValue(true,8192);
 // Atomics pass UI wheel changes to the audio thread without touching the engine from the UI.
 pitchWheel.onValueChange=[this]{processor.uiPitch.store((int)pitchWheel.getValue());};pitchWheel.onDragEnd=[this]{pitchWheel.setValue(8192);};
 modWheel.setSliderStyle(juce::Slider::LinearVertical);modWheel.setTextBoxStyle(juce::Slider::NoTextBox,false,0,0);modWheel.setRange(0,127,1);modWheel.onValueChange=[this]{processor.uiMod.store((int)modWheel.getValue());};
 fit.setTooltip("Reset the window to a size that fits the current display");
 fit.onClick=[this]{fitToScreen(defaultZoom());};
 zoomMenu.setName("GUI zoom");
 zoomMenu.setTooltip("Resize the whole interface by percentage");
 for(int percent:zoomLevels)zoomMenu.addItem(juce::String(percent)+"%",percent);
 zoomMenu.onChange=[this]{
  if(const auto percent=zoomMenu.getSelectedId();percent>0)
   applyZoom(percent,surface.getWidth(),surface.getHeight());
 };
 status.setFont(12.f);
 fitToScreen(processor.editorZoomPercent>0?processor.editorZoomPercent:defaultZoom());
 showRack(false);startTimerHz(24);
}
DavoeSynthEditor::~DavoeSynthEditor(){stopTimer();setLookAndFeel(nullptr);}
void DavoeSynthEditor::showRack(bool on){rack=on;synthPage.setVisible(!on);effectsPage.setVisible(on);synthTab.setToggleState(!on,juce::dontSendNotification);effectsTab.setToggleState(on,juce::dontSendNotification);view.setViewPosition(0,0);resized();surface.repaint();}
void DavoeSynthEditor::refreshUserPatches(){
 userPatches=library.names();rebuildPresets();
}
int DavoeSynthEditor::activePreset()const{
 const auto userName=processor.currentUserPatch();
 if(userName.isEmpty())return processor.getCurrentProgram();
 const int index=userPatches.indexOf(userName);
 return index<0?-1:(int)davoe::presets.size()+index;
}
void DavoeSynthEditor::selectPreset(int index){
 if(index<(int)davoe::presets.size()){processor.setCurrentProgram(index);patchNotice.clear();return;}
 const int i=index-(int)davoe::presets.size();if(i<0||i>=userPatches.size())return;
 const auto name=userPatches[i];auto file=library.fileFor(name);juce::MemoryBlock data;
 if(file.getSize()>1024*1024||!file.loadFileAsData(data)||!processor.restorePatch(data.getData(),(int)data.getSize(),&name)){
  patchNotice="Could not load user patch: "+name;refreshUserPatches();
 }else patchNotice.clear();
}
void DavoeSynthEditor::promptForPatchName(){
 if(!patchPrompt.isVisible()){
  patchPromptStatus.setText("Save to User Patches",juce::dontSendNotification);
  patchName.setText(processor.currentUserPatch(),false);
  patchPrompt.setVisible(true);
  surface.repaint(patchPrompt.getBounds());
 }
 patchName.grabKeyboardFocus();
 patchName.selectAll();
}
void DavoeSynthEditor::closePatchPrompt(){
 patchPrompt.setVisible(false);
 surface.repaint(patchPrompt.getBounds());
 save.grabKeyboardFocus();
}
void DavoeSynthEditor::saveNamedPatch(){
 juce::MemoryBlock data;
 processor.getStateInformation(data);
 juce::String saved;
 const auto result=library.add(patchName.getText(),data,saved);
 if(result.failed()){
  patchPromptStatus.setText(result.getErrorMessage(),juce::dontSendNotification);
  return;
 }
 closePatchPrompt();
 processor.identifyUserPatch(saved);
 search.setText("",false);
 category.setSelectedId(9,juce::dontSendNotification);
 refreshUserPatches();
 patchNotice="Saved: "+saved;
}
void DavoeSynthEditor::patchFileMenu(){
 juce::PopupMenu menu;menu.addItem(1,"Load .vog file");menu.addItem(2,"Export current patch as .vog");menu.addSeparator();menu.addItem(3,"Refresh User Patches");
 const juce::Component::SafePointer<DavoeSynthEditor> guard(this);
 menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&load),[guard](int action){if(guard&&action!=0){if(action==3)guard->refreshUserPatches();else guard->choosePatchFile(action==2);}});
}
void DavoeSynthEditor::choosePatchFile(bool exporting){
 const auto folder=juce::File::getSpecialLocation(juce::File::userDocumentsDirectory);
 chooser=std::make_unique<juce::FileChooser>(exporting?"Export VOG patch":"Load VOG patch",exporting?folder.getChildFile("My VOG Patch.vog"):folder,"*.vog");
 const juce::Component::SafePointer<DavoeSynthEditor> guard(this);
 const int flags=juce::FileBrowserComponent::canSelectFiles|(exporting?juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::warnAboutOverwriting:juce::FileBrowserComponent::openMode);
 chooser->launchAsync(flags,[guard,exporting](const juce::FileChooser& c){
  if(!guard||c.getResult()==juce::File())return;
  const auto file=c.getResult();juce::MemoryBlock data;
  if(exporting){guard->processor.getStateInformation(data);guard->patchNotice=file.withFileExtension("vog").replaceWithData(data.getData(),data.getSize())?"Patch exported":"Could not export patch";}
  else{const juce::String imported;const bool ok=file.getSize()<=1024*1024&&file.loadFileAsData(data)&&guard->processor.restorePatch(data.getData(),(int)data.getSize(),&imported);
   guard->patchNotice=ok?"Patch file loaded — use Save Patch to add it":"Could not load this VOG patch";}
 });
}
void DavoeSynthEditor::rebuildPresets(){
 const auto revision=processor.patchRevision.load();
 const int factoryCount=(int)davoe::presets.size();
 const int ends[]={20,36,52,68,84,94,100};
 const int bank=category.getSelectedId()-2;
 const auto query=search.getText().trim();
 presets.clear(juce::dontSendNotification);visiblePrograms.clear();
 const auto add=[&](const juce::String& name,int index){if(query.isEmpty()||name.containsIgnoreCase(query)){presets.addItem(name,index+1);visiblePrograms.push_back(index);}};
 if(bank!=7){const int first=bank==8?100:(bank>0?ends[bank-1]:0),end=(bank<0||bank==8)?factoryCount:ends[bank];
  for(int i=first;i<end;++i)add(juce::String::fromUTF8(davoe::presets[(size_t)i].name),i);
 }
 if(bank<0||bank==7)for(int i=0;i<userPatches.size();++i)add(userPatches[i],factoryCount+i);
 presets.setTextWhenNothingSelected(visiblePrograms.empty()?(bank==7&&query.isEmpty()?"No user patches yet":"No matching presets"):"Select a matching preset");
 const int active=activePreset();
 if(std::find(visiblePrograms.begin(),visiblePrograms.end(),active)!=visiblePrograms.end())presets.setSelectedId(active+1,juce::dontSendNotification);
 previous.setEnabled(!visiblePrograms.empty());next.setEnabled(!visiblePrograms.empty());presets.setEnabled(!visiblePrograms.empty());
 selectedRevision=revision;
}
void DavoeSynthEditor::browse(int direction){
 if(visiblePrograms.empty())return;
 const auto found=std::find(visiblePrograms.begin(),visiblePrograms.end(),activePreset());
 const int count=(int)visiblePrograms.size();
 const int index=found==visiblePrograms.end()?(direction>0?-1:0):(int)(found-visiblePrograms.begin());
 selectPreset(visiblePrograms[(size_t)((index+direction+count)%count)]);
 rebuildPresets();
}
int DavoeSynthEditor::defaultZoom()const{
 return processor.wrapperType==juce::AudioProcessor::wrapperType_VST3?85:100;
}
void DavoeSynthEditor::fitToScreen(int preferredZoom){
 const auto& displays=juce::Desktop::getInstance().getDisplays();
 const auto* display=isShowing()?displays.getDisplayForRect(getScreenBounds()):displays.getPrimaryDisplay();
 const bool hosted=processor.wrapperType==juce::AudioProcessor::wrapperType_VST3;
 const int preferredWidth=hosted?820:1200,preferredHeight=hosted?520:760;
 if(display==nullptr){applyZoom(preferredZoom,preferredWidth,preferredHeight);return;}
 const float hostScale=juce::jmax(.1f,getTransform().mat00);
 const float availableWidth=(float)(display->userArea.getWidth()-48)/hostScale;
 const float availableHeight=(float)(display->userArea.getHeight()-90)/hostScale;
 int fittedZoom=zoomLevels.front();
 for(int percent:zoomLevels){
  if(percent<=preferredZoom&&720*percent/100.f<=availableWidth&&440*percent/100.f<=availableHeight)
   fittedZoom=percent;
 }
 const int w=juce::jlimit(720,preferredWidth,(int)(availableWidth*100.f/fittedZoom));
 const int h=juce::jlimit(440,preferredHeight,(int)(availableHeight*100.f/fittedZoom));
 applyZoom(fittedZoom,w,h);
}
void DavoeSynthEditor::applyZoom(int percent,int logicalWidth,int logicalHeight){
 zoomPercent=percent;
 processor.editorZoomPercent=percent;
 zoomMenu.setSelectedId(percent,juce::dontSendNotification);
 const float scale=percent*.01f;
 surface.setTransform(juce::AffineTransform::scale(scale));
 // The host owns the editor's transform. Scale the child and negotiate an actual window size.
 setResizeLimits(juce::roundToInt(720*scale),juce::roundToInt(440*scale),
                 juce::roundToInt(2000*scale),juce::roundToInt(1300*scale));
 const int w=juce::roundToInt(logicalWidth*scale),h=juce::roundToInt(logicalHeight*scale);
 if(getWidth()==w&&getHeight()==h)resized();else setSize(w,h);
}
void DavoeSynthEditor::resized(){
 if(synthPanels.size()<12||effectPanels.size()<5||!equalizer)return;
 const float unscale=100.f/zoomPercent;
 surface.setBounds(0,0,juce::jmax(720,juce::roundToInt(getWidth()*unscale)),
                       juce::jmax(440,juce::roundToInt(getHeight()*unscale)));
 patchPrompt.setBounds((surface.getWidth()-388)/2,150,388,84);
 patchPromptStatus.setBounds(12,4,364,24);
 patchName.setBounds(12,32,207,37);
 confirmPatch.setBounds(225,32,68,37);
 cancelPatch.setBounds(299,32,77,37);
 auto r=surface.getLocalBounds().reduced(30,12);
 auto header=r.removeFromTop(134);
 auto controls=header.withTrimmedLeft(274);
 fit.setBounds(190,111,42,25);
 zoomMenu.setBounds(237,111,60,25);

 auto place=[&](juce::Rectangle<int>& row,juce::Component& control,int width,int gap=7){
  control.setBounds(row.removeFromLeft(width));
  row.removeFromLeft(gap);
 };
 auto browseRow=controls.removeFromTop(32).reduced(0,2);
 place(browseRow,category,118);
 place(browseRow,search,230,0);

 auto presetRow=controls.removeFromTop(32).reduced(0,2);
 place(presetRow,previous,28,5);
 place(presetRow,presets,294,5);
 place(presetRow,next,28,0);

 auto tabRow=controls.removeFromTop(32).reduced(0,2);
 place(tabRow,synthTab,108);
 place(tabRow,effectsTab,108);
 place(tabRow,panic,64,0);

 auto fileRow=controls.removeFromTop(32).reduced(0,2);
 place(fileRow,record,78);
 place(fileRow,saveWav,82);
 place(fileRow,save,88);
 place(fileRow,load,88,0);
 auto foot=r.removeFromBottom(30);status.setBounds(foot.withTrimmedRight(215));
 auto keys=r.removeFromBottom(surface.getHeight()<580?86:(surface.getHeight()<900?112:142));keys.removeFromTop(7);
 const int wheelHeight=keys.getHeight()-24;
 pitchLabel.setBounds(keys.getX(),keys.getY(),44,22);modLabel.setBounds(keys.getX()+48,keys.getY(),44,22);
 pitchWheel.setBounds(keys.getX()+3,keys.getY()+24,38,wheelHeight);modWheel.setBounds(keys.getX()+51,keys.getY()+24,38,wheelHeight);
 auto keyboardBounds=keys.withTrimmedLeft(104);
 keyboard.setBounds(keyboardBounds);
 keyboard.setKeyWidth((float)keyboardBounds.getWidth()/42.f);
 r.removeFromBottom(8);view.setBounds(r);
 const int width=juce::jmax(1,view.getWidth()-view.getScrollBarThickness());
 const bool wide=width>=1400;
 auto tile=[&](juce::Component& panel,int index,int columns,int y,int h){const int span=width+10;const int col=index%columns;const int left=col*span/columns;panel.setBounds(left,y+index/columns*(h+10),(col+1)*span/columns-left-10,h);};
 const int firstCols=wide?6:(width>=950?3:2);
 synthPanels[9]->columns=9;const int arpHeight=width<950?198:172;synthPanels[9]->setBounds(0,0,width,arpHeight);
 const int firstTop=arpHeight+10;
 for(int i=0;i<6;i++)tile(*synthPanels[(size_t)i],i,firstCols,firstTop,324);
 const int secondTop=firstTop+(6/firstCols)*334;
 const int order[]={6,7,8,10,11},secondCols=wide?5:(width>=950?3:2);
 for(int i=0;i<5;i++)tile(*synthPanels[(size_t)order[i]],i,secondCols,secondTop,280);

 const int fxCols=wide?3:2;
 juce::Component* effects[]={effectPanels[0].get(),equalizer.get(),effectPanels[1].get(),effectPanels[2].get(),effectPanels[3].get(),effectPanels[4].get()};
 for(int i=0;i<6;i++)tile(*effects[i],i,fxCols,0,368);
 const int synthHeight=secondTop+((5+secondCols-1)/secondCols)*290-10,fxHeight=(6/fxCols)*378-10;
 canvas.setSize(width,rack?fxHeight:synthHeight);synthPage.setBounds(0,0,width,synthHeight);effectsPage.setBounds(0,0,width,fxHeight);
}
void DavoeSynthEditor::paint(juce::Graphics& g){g.fillAll(davoeui::bg);}
void DavoeSynthEditor::paintSurface(juce::Graphics& g){using namespace davoeui;g.fillAll(bg);for(int side=0;side<2;side++){int x=side==0?0:surface.getWidth()-23;g.setGradientFill(juce::ColourGradient(juce::Colour(0xff25100b),(float)x,0,juce::Colour(0xff603a23),(float)x+23,0,false));g.fillRect(x,0,23,surface.getHeight());g.setColour(juce::Colours::black.withAlpha(.25f));for(int k=0;k<9;k++){juce::Path grain;grain.startNewSubPath((float)x+2+k*2,0);for(int y=0;y<=surface.getHeight();y+=20)grain.lineTo((float)x+2+k*2+std::sin(y*.014f+k)*1.8f,(float)y);g.strokePath(grain,juce::PathStrokeType(.7f));}}
 g.setGradientFill(juce::ColourGradient(juce::Colour(0xffdbdcd3),0,0,juce::Colour(0xff525d58),0,8,false));g.fillRect(23,0,surface.getWidth()-46,7);g.fillRect(23,surface.getHeight()-7,surface.getWidth()-46,7);
 const auto titleFont=headingFont(114.f);
 g.setColour(cream);g.setFont(titleFont);
 g.drawText("VOG",40,6,256,108,juce::Justification::centredLeft);
 const float oCentre=40.f+titleFont.getStringWidthFloat("V")+titleFont.getStringWidthFloat("O")*.5f;
 g.setColour(juce::Colour(0xffe7bc72));
 const auto eighthNote=[&g](float x,float y,float size){
  g.fillEllipse(x-size*.28f,y-size*.15f,size*.48f,size*.31f);
  g.drawLine(x+size*.13f,y,x+size*.13f,y-size*.78f,size*.10f);
  juce::Path flag;flag.startNewSubPath(x+size*.13f,y-size*.78f);
  flag.quadraticTo(x+size*.53f,y-size*.62f,x+size*.45f,y-size*.32f);
  flag.quadraticTo(x+size*.36f,y-size*.50f,x+size*.13f,y-size*.53f);
  flag.closeSubPath();g.fillPath(flag);
 };
 eighthNote(oCentre-19.f,25.f,12.f);
 eighthNote(oCentre+9.f,56.f,15.f);
 eighthNote(oCentre-10.f,72.f,12.f);
 eighthNote(oCentre+24.f,109.f,11.f);
 g.setFont(12.f);g.setColour(muted);
 g.drawText("VOICE OF GOD  /  v1.7.13",44,112,145,22,juce::Justification::centredLeft);
 const auto activeTab=(rack?effectsTab:synthTab).getBounds();
 g.setColour(cream);
 g.fillRoundedRectangle((float)activeTab.getCentreX()-14.f,(float)activeTab.getBottom()+1.f,28.f,2.f,1.f);
 int x=surface.getWidth()-230,y=surface.getHeight()-36;float l=processor.peakL.load(),r=processor.peakR.load();for(int c=0;c<2;c++){float db=20*std::log10(std::max(.00001f,c? r:l));float val=juce::jlimit(0.f,1.f,(db+60)/60);g.setColour(juce::Colour(0xff0b110d));g.fillRect(x,y+c*8,160,6);g.setColour(val>.94f?red:green);g.fillRect(x,y+c*8,(int)(160*val),6);}g.setColour(cream);g.setFont(11.f);g.drawText("OUT",x+168,y,30,16,juce::Justification::centredLeft);
}
void DavoeSynthEditor::timerCallback(){effectPanels[0]->getProperties().set("gr",processor.grMeter.load());if(rack)effectPanels[0]->repaint();if(processor.patchRevision.load()!=selectedRevision)rebuildPresets();const bool capturing=processor.recording.load();const float seconds=processor.recordedSeconds.load();const int whole=(int)seconds;const auto elapsed=juce::String::formatted("%02d:%02d",whole/60,whole%60);record.setToggleState(capturing,juce::dontSendNotification);record.setButtonText(capturing?"STOP "+elapsed:juce::String("REC"));saveWav.setEnabled(!capturing&&seconds>0.f);const auto captureStatus=capturing?"REC "+elapsed+" / 03:00     •     ":recordingNotice.isNotEmpty()?recordingNotice+"     •     ":seconds>0.f?"Take "+elapsed+" ready     •     ":juce::String();status.setText(captureStatus+(patchNotice.isNotEmpty()?patchNotice+"     •     ":juce::String())+juce::String(processor.voiceMeter.load())+" / 16 VOICES     •     "+juce::String(processor.bpmMeter.load(),1)+" BPM     •     COMP GR "+juce::String(processor.grMeter.load(),1)+" dB     •     MIDI: A–K or hardware keyboard",juce::dontSendNotification);surface.repaint(juce::Rectangle<int>(surface.getWidth()-240,surface.getHeight()-40,220,28));}
