# Install on Windows
1. Download the successful GitHub run's Voice-of-God-Windows-x64-v1.7.13 artifact.
2. Right-click the downloaded ZIP, choose Extract All. If an inner ZIP exists, extract that too.
3. Copy the entire Voice of God.vst3 folder to:
   C:\Program Files\Common Files\VST3
   Windows may ask for administrator permission for this copy.
4. Restart your DAW and rescan VST3 instruments.
5. Add Voice of God to a MIDI/instrument track, enable MIDI input, and play.

For standalone use, run Voice of God.exe from the package. Open its audio/MIDI settings and choose your audio output device and MIDI input. Use headphones or speakers connected to that output device.

Uninstall: close the DAW and remove the installed .vst3 folder. Keep .vog patch files if you want them. No registry installation is required.
