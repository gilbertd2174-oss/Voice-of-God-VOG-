#include "PluginEditor.h"
namespace davoeui {
Theme::Theme(){setColour(juce::ResizableWindow::backgroundColourId,bg);setColour(juce::Label::textColourId,cream);setColour(juce::Slider::textBoxTextColourId,juce::Colour(0xff171a16));setColour(juce::Slider::textBoxBackgroundColourId,juce::Colour(0xffe6dec8));setColour(juce::Slider::textBoxOutlineColourId,juce::Colour(0xff4b514b));setColour(juce::ComboBox::backgroundColourId,juce::Colour(0xff101616));setColour(juce::ComboBox::textColourId,cream);setColour(juce::ComboBox::outlineColourId,juce::Colour(0xff666b5c));setColour(juce::PopupMenu::backgroundColourId,bg);setColour(juce::PopupMenu::textColourId,cream);setColour(juce::TextButton::buttonColourId,juce::Colour(0xff471f2c));setColour(juce::TextButton::textColourOffId,cream);setColour(juce::Slider::thumbColourId,cream);setColour(juce::Slider::trackColourId,green);}
void Theme::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float start,float end,juce::Slider&){
 float size=juce::jmax(8.f,(float)juce::jmin(w,h)-16.f);auto r=juce::Rectangle<float>((float)x+((float)w-size)*.5f,(float)y+((float)h-size)*.5f,size,size);auto c=r.getCentre();float radius=size*.5f;
 g.setColour(juce::Colours::black.withAlpha(.6f));g.fillEllipse(r.translated(2.f,5.f).expanded(3.f));
 for(int i=0;i<=10;i++){float a=start+(end-start)*i/10.f;g.setColour(i<=pos*10?cream:juce::Colour(0xff636659));g.drawLine(c.x+std::sin(a)*(radius+3),c.y-std::cos(a)*(radius+3),c.x+std::sin(a)*(radius+6),c.y-std::cos(a)*(radius+6),1);}
 juce::ColourGradient rim(juce::Colour(0xff3b5379),r.getTopLeft(),juce::Colour(0xff0c1426),r.getBottomRight(),false);rim.addColour(.48,juce::Colour(0xff192d51));g.setGradientFill(rim);g.fillEllipse(r);
 auto inner=r.reduced(4);g.setGradientFill(juce::ColourGradient(juce::Colour(0xff29292e),inner.getTopLeft(),juce::Colour(0xff08090c),inner.getBottomRight(),false));g.fillEllipse(inner);
 g.setColour(juce::Colours::white.withAlpha(.07f));for(int i=0;i<28;i++){float a=2*davoe::pi*i/28;g.drawLine(c.x+std::sin(a)*(radius-5),c.y+std::cos(a)*(radius-5),c.x+std::sin(a)*(radius-8),c.y+std::cos(a)*(radius-8),1);}
 g.setColour(juce::Colours::white.withAlpha(.19f));g.drawEllipse(inner.reduced(2.f),.8f);float angle=start+pos*(end-start);g.setColour(juce::Colour(0xffffd783));g.drawLine(c.x+std::sin(angle)*radius*.24f,c.y-std::cos(angle)*radius*.24f,c.x+std::sin(angle)*radius*.75f,c.y-std::cos(angle)*radius*.75f,2.8f);
}
Control::Control(juce::AudioProcessorValueTreeState& state,davoe::Param id,bool compactLabel):labelBesideBox(compactLabel){auto& spec=davoe::specs[(size_t)id];addAndMakeVisible(label);label.setText(spec.name,juce::dontSendNotification);label.setJustificationType(juce::Justification::centred);label.setFont(juce::Font(13.f,juce::Font::bold));label.setTooltip(spec.help);
 if(spec.choices[0]){addAndMakeVisible(choice);auto strings=juce::StringArray::fromTokens(spec.choices,"|","");choice.addItemList(strings,1);choice.setTooltip(spec.help);ca=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(state,spec.id,choice);}
 else{addAndMakeVisible(knob);knob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);knob.setTextBoxStyle(juce::Slider::TextBoxBelow,false,78,20);knob.setDoubleClickReturnValue(true,spec.initial);knob.setTooltip(spec.help);knob.setName(spec.name);sa=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(state,spec.id,knob);}
}
void Control::resized(){auto r=getLocalBounds();label.setBounds(r.removeFromTop(22));if(ca){auto box=r.reduced(5,juce::jmax(2,(r.getHeight()-30)/2));choice.setBounds(box);if(labelBesideBox)label.setBounds(0,juce::jmax(0,box.getY()-24),getWidth(),22);}else knob.setBounds(r.reduced(4,1));}
Panel::Panel(juce::AudioProcessorValueTreeState& state,juce::String name,juce::String sub,juce::Colour col,int cols,std::initializer_list<davoe::Param> ids):title(name),subtitle(sub),accent(col),columns(cols){for(auto id:ids){auto c=std::make_unique<Control>(state,id,title=="ARPEGGIATOR");addAndMakeVisible(*c);controls.push_back(std::move(c));}}
void Panel::paint(juce::Graphics& g){auto r=getLocalBounds().toFloat().reduced(1);g.setGradientFill(juce::ColourGradient(juce::Colour(0xff242526),r.getTopLeft(),juce::Colour(0xff111214),r.getBottomRight(),false));g.fillRoundedRectangle(r,8);g.setColour(juce::Colour(0xff781d28));g.drawRoundedRectangle(r,8,2.f);g.setColour(cream);g.setFont(juce::Font(17.f,juce::Font::bold));g.drawText(title,14,9,getWidth()-28,22,juce::Justification::centredLeft);g.setColour(muted);g.setFont(11.f);if(title=="ARPEGGIATOR")g.drawText(subtitle,190,10,getWidth()-212,20,juce::Justification::centredRight);else g.drawText(subtitle,14,31,getWidth()-28,16,juce::Justification::centredLeft);if(title.contains("COMPRESSOR")){auto meter=juce::Rectangle<float>((float)getWidth()-126,9,108,32);g.setColour(juce::Colour(0xffd9ca91));g.fillRoundedRectangle(meter,3);g.setColour(juce::Colour(0xff413c26));g.setFont(9.f);g.drawText("GAIN REDUCTION",meter.toNearestInt().withTrimmedTop(19),juce::Justification::centred);float gr=(float)getProperties().getWithDefault("gr",0.f);float a=-.9f+juce::jlimit(0.f,1.f,gr/24.f)*1.8f;g.setColour(red);g.drawLine(meter.getCentreX(),meter.getBottom()-9,meter.getCentreX()+std::sin(a)*28,meter.getBottom()-9-std::cos(a)*21,1.7f);}
 for(int x:{8,getWidth()-12}){g.setColour(juce::Colour(0xff7b8275));g.fillEllipse((float)x,8,4,4);g.setColour(juce::Colours::black);g.drawLine((float)x,10,(float)x+4,10,1);}}
void Panel::resized(){auto r=getLocalBounds().reduced(8);r.removeFromTop(43);
 if(title=="ARPEGGIATOR"&&controls.size()==8){
  r=getLocalBounds().reduced(8,5);r.removeFromTop(28);
  auto place=[&](juce::Rectangle<int> area,std::initializer_list<int> indices){
   int slot=0,count=(int)indices.size();
   for(int index:indices){
    const int a=slot*area.getWidth()/count,b=(slot+1)*area.getWidth()/count;
    controls[(size_t)index]->setBounds(area.getX()+a,area.getY(),b-a,area.getHeight());
    ++slot;
   }
  };
  if(getWidth()<950){
   auto knobs=r.removeFromTop(r.getHeight()-58);
   knobs.setWidth(knobs.getWidth()*2/3);knobs.setX((getWidth()-knobs.getWidth())/2);
   place(knobs,{4,5,6});place(r,{0,1,2,3,7});
  }else{
   const int side=r.getWidth()/3;
   const auto left=r.removeFromLeft(side),right=r.removeFromRight(side);
   place(left,{0,1});place(r,{4,5,6});place(right,{2,3,7});
  }
  return;
 }
 int rows=((int)controls.size()+columns-1)/columns;for(size_t i=0;i<controls.size();i++){int col=(int)i%columns,row=(int)i/columns;int w=r.getWidth()/columns,h=r.getHeight()/rows;controls[i]->setBounds(r.getX()+col*w,r.getY()+row*h,w,h);}}
EQPanel::EQPanel(juce::AudioProcessorValueTreeState& state){on=std::make_unique<Control>(state,davoe::EqOn);width=std::make_unique<Control>(state,davoe::EqWidth);addAndMakeVisible(*on);addAndMakeVisible(*width);for(size_t i=0;i<7;i++){auto& s=davoe::specs[(size_t)davoe::Eq100+i];auto& f=faders[i];addAndMakeVisible(f);f.setSliderStyle(juce::Slider::LinearVertical);f.setTextBoxStyle(juce::Slider::TextBoxBelow,false,54,20);f.setDoubleClickReturnValue(true,0);f.setTooltip(s.help);attachments[i]=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(state,s.id,f);addAndMakeVisible(labels[i]);labels[i].setText(s.name,juce::dontSendNotification);labels[i].setJustificationType(juce::Justification::centred);labels[i].setFont(12.f);}}
void EQPanel::paint(juce::Graphics& g){g.setColour(juce::Colour(0xff17181a));g.fillRoundedRectangle(getLocalBounds().toFloat().reduced(1),8);g.setColour(juce::Colour(0xff781d28));g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(1),8,1.2f);g.setColour(cream);g.setFont(juce::Font(17.f,juce::Font::bold));g.drawText("SEVEN-BAND EQUALIZER",14,10,getWidth()-28,24,juce::Justification::centredLeft);g.setColour(muted);g.setFont(11.f);g.drawText("±15 dB • Double-click a fader to reset",14,34,getWidth()-28,16,juce::Justification::centredLeft);g.setColour(cream.withAlpha(.12f));g.drawHorizontalLine(155,12.f,(float)getWidth()-12);}
void EQPanel::resized(){int w=(getWidth()-18)/7;for(int i=0;i<7;i++){labels[(size_t)i].setBounds(9+i*w,55,w,21);faders[(size_t)i].setBounds(9+i*w,80,w,168);}on->setBounds(8,260,getWidth()/2-12,88);width->setBounds(getWidth()/2,250,getWidth()/2-8,104);}
}
DavoeSynthEditor::DavoeSynthEditor(DavoeSynthProcessor& p):AudioProcessorEditor(p),processor(p),keyboard(p.keyboard,juce::MidiKeyboardComponent::horizontalKeyboard){
 using namespace davoe;using namespace davoeui;setLookAndFeel(&theme);setResizable(true,true);setResizeLimits(720,440,2000,1300);
 addAndMakeVisible(view);view.setViewedComponent(&canvas,false);view.setScrollBarsShown(true,false);canvas.addAndMakeVisible(synthPage);canvas.addChildComponent(effectsPage);
 auto panel=[&](juce::Component& page,std::vector<std::unique_ptr<Panel>>& list,const char* title,const char* sub,juce::Colour c,int cols,std::initializer_list<Param> ids){auto x=std::make_unique<Panel>(p.state,title,sub,c,cols,ids);page.addAndMakeVisible(*x);list.push_back(std::move(x));};
 panel(synthPage,synthPanels,"OSCILLATOR 1","Band-limited • analog waveforms",red,2,{Wave1,Octave1,Level1,Pulse1});
 panel(synthPage,synthPanels,"OSCILLATOR 2","Independent pitch • fine detuning",red,2,{Wave2,Octave2,Level2,Detune,Pulse2});
 panel(synthPage,synthPanels,"OSCILLATOR 3","Independent wave • octave • fine tune",red,2,{Wave3,Octave3,Level3,Detune3,Pulse3});
 panel(synthPage,synthPanels,"OSCILLATOR 4","Independent wave • octave • fine tune",red,2,{Wave4,Octave4,Level4,Detune4,Pulse4});
 panel(synthPage,synthPanels,"SOURCE MIXER","Sub • noise • warmth • width",cream,2,{Sub,Noise,Drive,Spread});
 panel(synthPage,synthPanels,"RESONANT FILTER","Low pass • high pass • band pass",green,2,{FilterMode,Cutoff,Resonance,EnvAmount,KeyTrack});
 panel(synthPage,synthPanels,"AMPLITUDE","ADSR • velocity sensitive",red,2,{AmpA,AmpD,AmpS,AmpR});
 panel(synthPage,synthPanels,"FILTER ENVELOPE","Independent ADSR contour",green,2,{FilterA,FilterD,FilterS,FilterR});
 panel(synthPage,synthPanels,"LOW FREQUENCY OSCILLATOR","Pitch • filter • PWM • tremolo",red,3,{LfoShape,LfoRate,LfoPitch,LfoFilter,LfoPWM,LfoAmp});
 panel(synthPage,synthPanels,"ARPEGGIATOR","Hold • DAW or internal clock • 5–240 BPM",cream,4,{ArpOn,ArpMode,ArpRate,ArpHold,ArpOctaves,ArpGate,Tempo,ArpClock});
 panel(synthPage,synthPanels,"SPACE & MOTION","Full controls on the effects page",green,3,{Chorus,DelayMix,DelayTime,Feedback,Reverb,Space});
 panel(synthPage,synthPanels,"PERFORMANCE","MIDI pitch bend • mono glide",cream,2,{Mono,Glide,BendRange,Master});
 panel(effectsPage,effectPanels,"DYNAMICS / COMPRESSOR","Stereo linked • parallel compression",red,4,{CompOn,CompThreshold,CompRatio,CompAttack,CompRelease,CompMakeup,CompMix});
 equalizer=std::make_unique<EQPanel>(p.state);effectsPage.addAndMakeVisible(*equalizer);
 panel(effectsPage,effectPanels,"DISTORTION & TONE","Tube • fuzz • saturation",red,4,{DistOn,DistMode,DistDrive,DistBass,DistMid,DistTreble,DistLevel,DistMix});
 panel(effectsPage,effectPanels,"MULTI-HEAD TAPE ECHO","Three heads • wow/flutter • tempo sync",green,4,{EchoOn,EchoHeads,EchoSync,DelayTime,Feedback,DelayMix,EchoWow});
 panel(effectsPage,effectPanels,"LUSH REVERB","Pre-delay • early reflections • modulation",juce::Colour(0xffada0ca),4,{VerbOn,Reverb,PreDelay,Early,Space,VerbDecay,VerbDamp,VerbHigh,VerbLow,VerbRate,VerbDepth});
 panel(effectsPage,effectPanels,"EFFECTS MODULATOR","Echo feedback • room mix • chorus",cream,4,{FxRate,FxShape,FxDepth,FxSync,FxWheel,FxKeyReset,Chorus});
 for(auto* c:std::initializer_list<juce::Component*>{&previous,&next,&search,&category,&presets,&synthTab,&effectsTab,&panic,&save,&load,&record,&saveWav,&fit,&keyboard,&status,&pitchWheel,&modWheel,&pitchLabel,&modLabel})addAndMakeVisible(*c);
 category.addItemList({"All sounds","Essentials","Bass","Leads","Pads & strings","Keys & plucks","Arps","Textures","User Patches"},1);
 category.setSelectedId(1,juce::dontSendNotification);category.onChange=[this]{refreshUserPatches();};
 search.setSingleLine(true);search.setTextToShowWhenEmpty("Find a preset...",muted);search.setColour(juce::TextEditor::backgroundColourId,juce::Colour(0xff101616));search.setColour(juce::TextEditor::textColourId,cream);search.onTextChange=[this]{rebuildPresets();};
 previous.setTooltip("Previous matching preset");next.setTooltip("Next matching preset");
 previous.onClick=[this]{browse(-1);};next.onClick=[this]{browse(1);};
 search.onReturnKey=[this]{if(visiblePrograms.size()==1)selectPreset(visiblePrograms.front());};
 search.onEscapeKey=[this]{search.clear();keyboard.grabKeyboardFocus();};
 presets.onChange=[this]{if(presets.getSelectedId()>0)selectPreset(presets.getSelectedId()-1);};
 refreshUserPatches();
 synthTab.onClick=[this]{showRack(false);};effectsTab.onClick=[this]{showRack(true);};panic.onClick=[this]{processor.panicRequested.store(true);};panic.setTooltip("Stop all voices, clear latched notes and effect tails");
 const juce::Component::SafePointer<DavoeSynthEditor> editorGuard(this);
 record.setColour(juce::TextButton::buttonOnColourId,juce::Colour(0xff942837));
 record.setTooltip("Record this synth in stereo for up to three minutes. Starting a take replaces the previous take.");
 saveWav.setTooltip("Save the stopped take as a 16-bit stereo WAV");
 record.onClick=[this]{recordingNotice.clear();if(processor.recording.load())processor.stopRecording();else{auto result=processor.startRecording();if(result.failed())recordingNotice=result.getErrorMessage();}};
 saveWav.onClick=[this,editorGuard]{
  chooser=std::make_unique<juce::FileChooser>("Save VOG recording",juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("VOG Recording.wav"),"*.wav");
  chooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting,[safe=editorGuard](const juce::FileChooser& c){if(safe&&c.getResult()!=juce::File()){auto result=safe->processor.saveRecording(c.getResult());safe->recordingNotice=result.wasOk()?"WAV saved":result.getErrorMessage();}});
 };

 save.onClick=[this]{promptForPatchName();};
 load.onClick=[this]{patchFileMenu();};
 load.setTooltip("Import or export a .vog file");
 keyboard.setAvailableRange(36,96);keyboard.setLowestVisibleKey(36);keyboard.setKeyWidth(25);keyboard.setColour(juce::MidiKeyboardComponent::whiteNoteColourId,juce::Colour(0xffe7e0cc));keyboard.setColour(juce::MidiKeyboardComponent::blackNoteColourId,juce::Colour(0xff101514));keyboard.setColour(juce::MidiKeyboardComponent::keyDownOverlayColourId,red.withAlpha(.65f));keyboard.setWantsKeyboardFocus(true);
 pitchLabel.setText("PITCH",juce::dontSendNotification);modLabel.setText("MOD",juce::dontSendNotification);pitchLabel.setJustificationType(juce::Justification::centred);modLabel.setJustificationType(juce::Justification::centred);
 pitchWheel.setSliderStyle(juce::Slider::LinearVertical);pitchWheel.setTextBoxStyle(juce::Slider::NoTextBox,false,0,0);pitchWheel.setRange(0,16383,1);pitchWheel.setValue(8192);pitchWheel.setDoubleClickReturnValue(true,8192);
 // Atomics pass UI wheel changes to the audio thread without touching the engine from the UI.
 pitchWheel.onValueChange=[this]{processor.uiPitch.store((int)pitchWheel.getValue());};pitchWheel.onDragEnd=[this]{pitchWheel.setValue(8192);};
 modWheel.setSliderStyle(juce::Slider::LinearVertical);modWheel.setTextBoxStyle(juce::Slider::NoTextBox,false,0,0);modWheel.setRange(0,127,1);modWheel.onValueChange=[this]{processor.uiMod.store((int)modWheel.getValue());};
 fit.setTooltip("Fit the synth window to the current display");fit.onClick=[this]{fitToScreen();};
 status.setFont(12.f);fitToScreen();showRack(false);startTimerHz(24);
}
DavoeSynthEditor::~DavoeSynthEditor(){stopTimer();setLookAndFeel(nullptr);}
void DavoeSynthEditor::showRack(bool on){rack=on;synthPage.setVisible(!on);effectsPage.setVisible(on);synthTab.setToggleState(!on,juce::dontSendNotification);effectsTab.setToggleState(on,juce::dontSendNotification);view.setViewPosition(0,0);resized();repaint();}
void DavoeSynthEditor::refreshUserPatches(){
 userPatches=library.names();rebuildPresets();
}
int DavoeSynthEditor::activePreset()const{
 const auto userName=processor.currentUserPatch();
 if(userName.isEmpty())return processor.getCurrentProgram();
 const int index=userPatches.indexOf(userName);
 return index<0?-1:(int)davoe::presets.size()+index;
}
void DavoeSynthEditor::selectPreset(int index){
 if(index<(int)davoe::presets.size()){processor.setCurrentProgram(index);patchNotice.clear();return;}
 const int i=index-(int)davoe::presets.size();if(i<0||i>=userPatches.size())return;
 const auto name=userPatches[i];auto file=library.fileFor(name);juce::MemoryBlock data;
 if(file.getSize()>1024*1024||!file.loadFileAsData(data)||!processor.restorePatch(data.getData(),(int)data.getSize(),&name)){
  patchNotice="Could not load user patch: "+name;refreshUserPatches();
 }else patchNotice.clear();
}
void DavoeSynthEditor::promptForPatchName(){
 if(nameDialog&&nameDialog->isCurrentlyModal())return;
 nameDialog=std::make_unique<juce::AlertWindow>("Save new user patch","Name this sound. It will appear in User Patches.",juce::MessageBoxIconType::NoIcon,this);
 nameDialog->addTextEditor("name",processor.currentUserPatch(),"Patch name");
 nameDialog->addButton("Save new patch",1,juce::KeyPress(juce::KeyPress::returnKey));
 nameDialog->addButton("Cancel",0,juce::KeyPress(juce::KeyPress::escapeKey));
 const juce::Component::SafePointer<DavoeSynthEditor> guard(this);
 nameDialog->enterModalState(true,juce::ModalCallbackFunction::create([guard](int action){
  if(!guard||action!=1||!guard->nameDialog)return;
  const auto requested=guard->nameDialog->getTextEditorContents("name");
  juce::MemoryBlock data;guard->processor.getStateInformation(data);juce::String saved;
  const auto result=guard->library.add(requested,data,saved);
  if(result.failed()){guard->patchNotice=result.getErrorMessage();return;}
  guard->processor.identifyUserPatch(saved);
  guard->search.setText("",false);guard->category.setSelectedId(9,juce::dontSendNotification);
  guard->refreshUserPatches();guard->patchNotice="Saved: "+saved;
 }),false);
}
void DavoeSynthEditor::patchFileMenu(){
 juce::PopupMenu menu;menu.addItem(1,"Load .vog file");menu.addItem(2,"Export current patch as .vog");menu.addSeparator();menu.addItem(3,"Refresh User Patches");
 const juce::Component::SafePointer<DavoeSynthEditor> guard(this);
 menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&load),[guard](int action){if(guard&&action!=0){if(action==3)guard->refreshUserPatches();else guard->choosePatchFile(action==2);}});
}
void DavoeSynthEditor::choosePatchFile(bool exporting){
 const auto folder=juce::File::getSpecialLocation(juce::File::userDocumentsDirectory);
 chooser=std::make_unique<juce::FileChooser>(exporting?"Export VOG patch":"Load VOG patch",exporting?folder.getChildFile("My VOG Patch.vog"):folder,"*.vog");
 const juce::Component::SafePointer<DavoeSynthEditor> guard(this);
 const int flags=juce::FileBrowserComponent::canSelectFiles|(exporting?juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::warnAboutOverwriting:juce::FileBrowserComponent::openMode);
 chooser->launchAsync(flags,[guard,exporting](const juce::FileChooser& c){
  if(!guard||c.getResult()==juce::File())return;
  const auto file=c.getResult();juce::MemoryBlock data;
  if(exporting){guard->processor.getStateInformation(data);guard->patchNotice=file.withFileExtension("vog").replaceWithData(data.getData(),data.getSize())?"Patch exported":"Could not export patch";}
  else{const juce::String imported;const bool ok=file.getSize()<=1024*1024&&file.loadFileAsData(data)&&guard->processor.restorePatch(data.getData(),(int)data.getSize(),&imported);
   guard->patchNotice=ok?"Patch file loaded — use Save Patch to add it":"Could not load this VOG patch";}
 });
}
void DavoeSynthEditor::rebuildPresets(){
 const auto revision=processor.patchRevision.load();
 const int factoryCount=(int)davoe::presets.size();
 const int ends[]={20,36,52,68,84,94,factoryCount};
 const int bank=category.getSelectedId()-2;
 const auto query=search.getText().trim();
 presets.clear(juce::dontSendNotification);visiblePrograms.clear();
 const auto add=[&](const juce::String& name,int index){if(query.isEmpty()||name.containsIgnoreCase(query)){presets.addItem(name,index+1);visiblePrograms.push_back(index);}};
 if(bank!=7){const int first=bank>0?ends[bank-1]:0,end=bank<0?factoryCount:ends[bank];
  for(int i=first;i<end;++i)add(juce::String::fromUTF8(davoe::presets[(size_t)i].name),i);
 }
 if(bank<0||bank==7)for(int i=0;i<userPatches.size();++i)add(userPatches[i],factoryCount+i);
 presets.setTextWhenNothingSelected(visiblePrograms.empty()?(bank==7&&query.isEmpty()?"No user patches yet":"No matching presets"):"Select a matching preset");
 const int active=activePreset();
 if(std::find(visiblePrograms.begin(),visiblePrograms.end(),active)!=visiblePrograms.end())presets.setSelectedId(active+1,juce::dontSendNotification);
 previous.setEnabled(!visiblePrograms.empty());next.setEnabled(!visiblePrograms.empty());presets.setEnabled(!visiblePrograms.empty());
 selectedRevision=revision;
}
void DavoeSynthEditor::browse(int direction){
 if(visiblePrograms.empty())return;
 const auto found=std::find(visiblePrograms.begin(),visiblePrograms.end(),activePreset());
 const int count=(int)visiblePrograms.size();
 const int index=found==visiblePrograms.end()?(direction>0?-1:0):(int)(found-visiblePrograms.begin());
 selectPreset(visiblePrograms[(size_t)((index+direction+count)%count)]);
 rebuildPresets();
}
void DavoeSynthEditor::fitToScreen(){
 const auto& displays=juce::Desktop::getInstance().getDisplays();
 const auto* display=isShowing()?displays.getDisplayForRect(getScreenBounds()):displays.getPrimaryDisplay();
 // Host chrome and Windows scaling can make a large editor hard to reach.
 const bool hosted=processor.wrapperType==juce::AudioProcessor::wrapperType_VST3;
 const int preferredWidth=hosted?820:1200;
 const int preferredHeight=hosted?520:760;
 const int w=display?juce::jlimit(720,preferredWidth,display->userArea.getWidth()-48):preferredWidth;
 const int h=display?juce::jlimit(440,preferredHeight,display->userArea.getHeight()-90):preferredHeight;
 setSize(w,h);
}
void DavoeSynthEditor::resized(){
 if(synthPanels.size()<12||effectPanels.size()<5||!equalizer)return;
 auto r=getLocalBounds().reduced(30,12);
 const bool compact=getWidth()<1080;
 fit.setBounds(122,24,48,26);
 auto header=r.removeFromTop(compact?105:76);
 auto top=header.removeFromTop(35).withTrimmedLeft(compact?156:230).reduced(0,2);
 category.setBounds(top.removeFromLeft(compact?106:124));top.removeFromLeft(7);
 search.setBounds(top.removeFromLeft(compact?110:148));top.removeFromLeft(7);
 previous.setBounds(top.removeFromLeft(compact?29:36));top.removeFromLeft(5);
 next.setBounds(top.removeFromRight(compact?29:36));top.removeFromRight(5);
 presets.setBounds(top);
 if(compact)header.removeFromTop(27);
 auto actions=header.removeFromTop(35).reduced(0,3);
 if(!compact)actions.removeFromLeft(230);
 synthTab.setBounds(actions.removeFromLeft(compact?100:140));actions.removeFromLeft(7);
 effectsTab.setBounds(actions.removeFromLeft(compact?100:140));
 panic.setBounds(actions.removeFromRight(compact?62:80));actions.removeFromRight(7);
 load.setBounds(actions.removeFromRight(compact?86:101));actions.removeFromRight(7);
 save.setBounds(actions.removeFromRight(compact?86:101));actions.removeFromRight(7);
 saveWav.setBounds(actions.removeFromRight(compact?78:93));actions.removeFromRight(7);
 record.setBounds(actions.removeFromRight(compact?78:91));
 auto foot=r.removeFromBottom(30);status.setBounds(foot.withTrimmedRight(215));
 auto keys=r.removeFromBottom(getHeight()<580?86:(getHeight()<900?112:142));keys.removeFromTop(7);
 const int wheelHeight=keys.getHeight()-24;
 pitchLabel.setBounds(keys.getX(),keys.getY(),44,22);modLabel.setBounds(keys.getX()+48,keys.getY(),44,22);
 pitchWheel.setBounds(keys.getX()+3,keys.getY()+24,38,wheelHeight);modWheel.setBounds(keys.getX()+51,keys.getY()+24,38,wheelHeight);
 keyboard.setBounds(keys.withTrimmedLeft(104));r.removeFromBottom(8);view.setBounds(r);
 const int width=juce::jmax(1,view.getWidth()-view.getScrollBarThickness());
 const bool wide=width>=1400;
 auto tile=[&](juce::Component& panel,int index,int columns,int y,int h){const int span=width+10;const int col=index%columns;const int left=col*span/columns;panel.setBounds(left,y+index/columns*(h+10),(col+1)*span/columns-left-10,h);};
 const int firstCols=wide?6:(width>=950?3:2);
 synthPanels[9]->columns=8;const int arpHeight=width<950?198:172;synthPanels[9]->setBounds(0,0,width,arpHeight);
 const int firstTop=arpHeight+10;
 for(int i=0;i<6;i++)tile(*synthPanels[(size_t)i],i,firstCols,firstTop,324);
 const int secondTop=firstTop+(6/firstCols)*334;
 const int order[]={6,7,8,10,11},secondCols=wide?5:(width>=950?3:2);
 for(int i=0;i<5;i++)tile(*synthPanels[(size_t)order[i]],i,secondCols,secondTop,280);

 const int fxCols=wide?3:2;
 juce::Component* effects[]={effectPanels[0].get(),equalizer.get(),effectPanels[1].get(),effectPanels[2].get(),effectPanels[3].get(),effectPanels[4].get()};
 for(int i=0;i<6;i++)tile(*effects[i],i,fxCols,0,368);
 const int synthHeight=secondTop+((5+secondCols-1)/secondCols)*290-10,fxHeight=(6/fxCols)*378-10;
 canvas.setSize(width,rack?fxHeight:synthHeight);synthPage.setBounds(0,0,width,synthHeight);effectsPage.setBounds(0,0,width,fxHeight);
}
void DavoeSynthEditor::paint(juce::Graphics& g){using namespace davoeui;g.fillAll(bg);for(int side=0;side<2;side++){int x=side==0?0:getWidth()-23;g.setGradientFill(juce::ColourGradient(juce::Colour(0xff25100b),(float)x,0,juce::Colour(0xff603a23),(float)x+23,0,false));g.fillRect(x,0,23,getHeight());g.setColour(juce::Colours::black.withAlpha(.25f));for(int k=0;k<9;k++){juce::Path grain;grain.startNewSubPath((float)x+2+k*2,0);for(int y=0;y<=getHeight();y+=20)grain.lineTo((float)x+2+k*2+std::sin(y*.014f+k)*1.8f,(float)y);g.strokePath(grain,juce::PathStrokeType(.7f));}}
 g.setGradientFill(juce::ColourGradient(juce::Colour(0xffdbdcd3),0,0,juce::Colour(0xff525d58),0,8,false));g.fillRect(23,0,getWidth()-46,7);g.fillRect(23,getHeight()-7,getWidth()-46,7);
 g.setColour(cream);g.setFont(juce::Font(30.f,juce::Font::bold));g.drawText("VOG",42,20,210,35,juce::Justification::centredLeft);g.setFont(12.f);g.setColour(muted);g.drawText("VOICE OF GOD  /  v1.3.5",44,55,360,20,juce::Justification::centredLeft);
 int x=getWidth()-230,y=getHeight()-36;float l=processor.peakL.load(),r=processor.peakR.load();for(int c=0;c<2;c++){float db=20*std::log10(std::max(.00001f,c? r:l));float val=juce::jlimit(0.f,1.f,(db+60)/60);g.setColour(juce::Colour(0xff0b110d));g.fillRect(x,y+c*8,160,6);g.setColour(val>.94f?red:green);g.fillRect(x,y+c*8,(int)(160*val),6);}g.setColour(cream);g.setFont(11.f);g.drawText("OUT",x+168,y,30,16,juce::Justification::centredLeft);
}
void DavoeSynthEditor::timerCallback(){effectPanels[0]->getProperties().set("gr",processor.grMeter.load());if(rack)effectPanels[0]->repaint();if(processor.patchRevision.load()!=selectedRevision)rebuildPresets();const bool capturing=processor.recording.load();const float seconds=processor.recordedSeconds.load();const int whole=(int)seconds;const auto elapsed=juce::String::formatted("%02d:%02d",whole/60,whole%60);record.setToggleState(capturing,juce::dontSendNotification);record.setButtonText(capturing?"STOP "+elapsed:juce::String("REC"));saveWav.setEnabled(!capturing&&seconds>0.f);const auto captureStatus=capturing?"REC "+elapsed+" / 03:00     •     ":recordingNotice.isNotEmpty()?recordingNotice+"     •     ":seconds>0.f?"Take "+elapsed+" ready     •     ":juce::String();status.setText(captureStatus+(patchNotice.isNotEmpty()?patchNotice+"     •     ":juce::String())+juce::String(processor.voiceMeter.load())+" / 16 VOICES     •     "+juce::String(processor.bpmMeter.load(),1)+" BPM     •     COMP GR "+juce::String(processor.grMeter.load(),1)+" dB     •     MIDI: A–K or hardware keyboard",juce::dontSendNotification);repaint(juce::Rectangle<int>(getWidth()-240,getHeight()-40,220,28));}
