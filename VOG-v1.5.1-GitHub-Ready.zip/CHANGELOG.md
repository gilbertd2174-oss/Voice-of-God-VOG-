# 1.5.1
- Fixed the user patch library test to read each saved file into its own buffer.
- Added a specific error message for each patch test failure.

# 1.5.0
- Added seven one-key chord types to the arpeggiator. Chord mode repeats full voicings across the selected octaves.
- Kept the scale runs and the synth’s manual polyphonic playing.

# 1.4.0
Added six scale modes to the arpeggiator, using the lowest held key as the root, with the existing octave, direction and Hold controls.

# 1.3.6
Use the supported JUCE 8.0.6 TextEditor single-line API. Report the first compiler/linker diagnostics at the end of failed builds.

# 1.3.5
VST3 opens in a smaller 820 × 520 window and FIT returns to that size. Standalone sizing is unchanged.

# 1.3.4
Smaller opening size, FIT button, narrower minimum, and compact settings layout.

# 1.3.3
Moved arpeggiator dropdown labels directly above their boxes.

# 1.3.2
Reduced arpeggiator panel height from 202 to 172 pixels. Its centered controls retain their large format.

# 1.3.1
Centered the large Octaves, Gate and Tempo controls in the arpeggiator, with the selectors on either side.

# 1.3.0
Named user patches, separate patch-file menu, black control panels, and arpeggiator above all synth settings.

# 1.2.0
Hold for normal notes and arp, three long divisions, 5 BPM internal clock, larger arp controls, burgundy/blue finish, +4 dB output boost, and three-minute stereo WAV capture.

# 1.1.0
Search and filter the original 100 presets, step through matches, and use narrower windows without horizontal scrolling. Improved knob contrast and ivory numeric readouts.

# 1.0.2
Remove unsupported MidiKeyboardComponent::setTooltip call (MSVC C2039). Keyboard playing instructions remain in the status bar and README.

# 1.0.1
Fix MSVC C2440 in Save/Load callbacks: construct the editor SafePointer in the editor constructor and capture that typed guard in asynchronous callbacks.

# 1.0.0
Initial Davoe analog-style instrument: four independent oscillators, synth page, effects rack, 100 presets, patch storage, Windows VST3 and standalone build configuration.
