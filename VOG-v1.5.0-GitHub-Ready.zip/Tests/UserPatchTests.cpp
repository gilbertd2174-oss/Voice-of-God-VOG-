#include "UserPatches.h"
#include <iostream>
int main(){
 const auto folder=juce::File::getSpecialLocation(juce::File::tempDirectory).getNonexistentChildFile("VOG-Patch-Test-"+juce::Uuid().toString(),"");
 struct Cleanup{juce::File folder;~Cleanup(){folder.deleteRecursively();}} cleanup{folder};
 davoe::UserPatches bank(folder);
 juce::String first,second;
 const char one[]="original",two[]="edited";
 juce::MemoryBlock a(one,sizeof(one)),b(two,sizeof(two)),read;
 if(bank.add("  ",a,first).wasOk()||!bank.names().isEmpty())return 1;
 if(bank.add("My Bass",a,first).failed()||bank.add("My Bass",b,second).failed()||first==second)return 2;
 davoe::UserPatches reopened(folder);
 const auto names=reopened.names();
 if(names.size()!=2||!names.contains(first)||!names.contains(second))return 3;
 if(!reopened.fileFor(first).loadFileAsData(read)||read!=a)return 4;
 if(!reopened.fileFor(second).loadFileAsData(read)||read!=b)return 5;
 std::cout<<"PASS: new names, duplicate save preserves original, library persists and data reloads\n";
}
