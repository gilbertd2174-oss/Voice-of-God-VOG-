# Validation status

## Completed locally
- Entire GitHub Actions YAML parsed; exactly six expected steps.
- Both PowerShell inline steps extracted from the parsed YAML and checked with the PowerShell syntax parser.
- Actual source ZIP extracted by the workflow's own script; its project-locator step checked the real project files and emitted the correct build directory.
- Parameter ID uniqueness, enum/spec counts, preset references/ranges, UI parameter coverage and archive integrity checked.
- Synth and effects-rack layout previews rendered and visually inspected. These are illustrative renders, not screenshots of a running plugin.

## Not completed in this environment
No CMake/C++ compiler or JUCE source checkout was available here. The Windows VST3 and standalone have NOT been compiled locally. EngineTests.cpp has NOT been executed here; GitHub Actions builds and executes it before publishing a binary. No listening, plugin-validation or DAW testing has been performed. This source project is an initial implementation awaiting that build and audio validation.

## Tests included for the Windows build
- All 100 factory preset parameter ranges.
- Independent audio output from each of the four oscillators.
- Finite/protected output at 44.1, 48 and 96 kHz.
- Note release, sustain pedal release, 16-voice allocation/stealing.
- Arpeggiator, latch and Panic clearing voices and tails.
- Audible output from every factory preset.
- Waveform × filter × distortion routes with synced effects modulation.

## Manual checks after a successful build
1. Launch standalone, select an audio output and MIDI input, play all presets.
2. In a DAW confirm stereo instrument loading, automation, state restore and MIDI event timing.
3. Confirm pitch wheel centering, sustain, mono glide, chord latch and Panic.
4. Exercise all effects on/off and extreme controls without clicks, runaway feedback or excessive CPU; lower levels while testing extreme patches.
5. Save/load .vog files and verify control values, then reopen a saved DAW session.
6. Test GUI scrolling/resizing at Windows scaling settings used on your machine.
7. Run a VST3 plugin validator and measure CPU at your preferred buffer size before treating this as production-ready.

## 1.0.1 compiler fix
The supplied GitHub log identified MSVC C2440 at PluginEditor.cpp:52 in the nested Save callback SafePointer capture. Both Save and Load now capture a typed guard created in the editor constructor. Source and archive checks passed; this correction still needs compilation on GitHub.

## 1.0.2 compiler fix
The follow-up GitHub build passed the callback code and reported one error C2039: MidiKeyboardComponent has no setTooltip member. Removed that optional tooltip call; keyboard behavior is unaffected. Archive checks passed; compilation remains to be verified on GitHub.

Version 1.1.0: package and workflow checks only. The revised JUCE UI has not been built or exercised in a DAW here. Previews are illustrative.

Version 1.2.0: package and workflow checks only. DSP tests now cover slow arp timing, Hold transitions, WAV PCM/header data and the recording limit. The C++ tests, DAW playback and native file save have not run locally.

Version 1.3.0: the Windows build includes a file-storage test covering library reopening, duplicate names and byte-for-byte reloads. It has not run locally. Native UI and DAW testing remain pending.

Version 1.3.4: source/package and workflow checks only. Compact editor behavior and DAW window scaling have not been exercised locally.

Version 1.3.5: package and workflow checks only. The resized VST3 has not been compiled or opened in Reason 14 here.

Version 1.3.6: verified the TextEditor replacement against the pinned JUCE header. Package and workflow checks are local; Windows compilation remains unverified.

Version 1.4.0: package and workflow checks only. Added C++ checks for scale intervals, octave span, descending order, the MIDI note ceiling and release. The Windows build and DSP checks remain unverified locally.

Version 1.5.0 adds DSP checks for chord voicing, simultaneous notes on mono patches, gate and release, switching back to scales, and manually played polyphonic chords. Windows compilation and host playback require verification.
