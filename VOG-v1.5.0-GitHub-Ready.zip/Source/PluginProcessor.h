#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include "SynthEngine.h"
#include "Presets.h"
#include "WaveCapture.h"
class DavoeSynthProcessor final:public juce::AudioProcessor {
public:
 DavoeSynthProcessor();
 void prepareToPlay(double,int)override;
 void releaseResources()override;
 void reset()override{panicRequested.store(true);}
 bool isBusesLayoutSupported(const BusesLayout&)const override;
 void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&)override;
 juce::AudioProcessorEditor* createEditor()override;
 bool hasEditor()const override{return true;}
 const juce::String getName()const override{return "Voice of God";}
 bool acceptsMidi()const override{return true;}bool producesMidi()const override{return false;}
 double getTailLengthSeconds()const override{return 20;}
 int getNumPrograms()override{return (int)davoe::presets.size();}
 int getCurrentProgram()override{return program.load();}
 void setCurrentProgram(int)override;
 const juce::String getProgramName(int i)override{return i>=0&&i<getNumPrograms()?juce::String::fromUTF8(davoe::presets[(size_t)i].name):juce::String();}
 void changeProgramName(int,const juce::String&)override{}
 void getStateInformation(juce::MemoryBlock&)override;
 void setStateInformation(const void*,int)override;
 bool restorePatch(const void*,int,const juce::String* userName=nullptr);
 juce::String currentUserPatch()const;void identifyUserPatch(const juce::String&);
 std::atomic<unsigned int> patchRevision{0};
 juce::AudioProcessorValueTreeState state;
 juce::MidiKeyboardState keyboard;
 juce::Result startRecording();void stopRecording();juce::Result saveRecording(const juce::File&);
 std::atomic<bool> recording{false};std::atomic<float> recordedSeconds{0.f};
 std::atomic<bool> panicRequested{false};
 std::atomic<int> uiPitch{-1},uiMod{-1};
 std::atomic<float> peakL{0},peakR{0},grMeter{0},bpmMeter{120};std::atomic<int> voiceMeter{0};
private:
 std::array<std::atomic<float>*,davoe::ParamCount> raw{};davoe::Engine engine;std::atomic<int> program{0};
 mutable juce::CriticalSection patchNameLock;juce::String userPatchName;std::atomic<bool> userPatchActive{false};
 juce::SpinLock captureLock;davoe::WaveCapture capture;std::atomic<unsigned int> captureRate{0};
 davoe::Values values()const;
 void midi(const juce::MidiMessage&);
 static juce::AudioProcessorValueTreeState::ParameterLayout layout();
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DavoeSynthProcessor)
};
