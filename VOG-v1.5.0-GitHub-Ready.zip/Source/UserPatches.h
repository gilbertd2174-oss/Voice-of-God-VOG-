#pragma once
#include <juce_core/juce_core.h>
namespace davoe {
class UserPatches {
 juce::File directory;
public:
 explicit UserPatches(juce::File folder):directory(std::move(folder)){}
 static UserPatches forCurrentUser(){
  return UserPatches(juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
       .getChildFile("Davoe Audio").getChildFile("Voice of God").getChildFile("User Patches"));
 }
 juce::StringArray names()const{
  juce::StringArray result;
  for(const auto& file:directory.findChildFiles(juce::File::findFiles,false,"*.vog"))result.add(file.getFileNameWithoutExtension());
  result.sort(true);return result;
 }
 juce::File fileFor(const juce::String& name)const{return directory.getChildFile(name+".vog");}
 juce::Result add(const juce::String& requested,const juce::MemoryBlock& data,juce::String& savedName)const{
  auto name=juce::File::createLegalFileName(requested.trim().substring(0,64)).trim().trimCharactersAtEnd(" .");
  if(name.isEmpty())return juce::Result::fail("Enter a patch name");
  // Windows device names cannot be used as filenames, even with an extension.
  const auto stem=name.upToFirstOccurrenceOf(".",false,false).toUpperCase().trimEnd();
  const juce::StringArray reserved{"CON","PRN","AUX","NUL","COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9","LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9"};
  if(reserved.contains(stem))name="Patch "+name;
  if(auto result=directory.createDirectory();result.failed())return result;
  auto file=directory.getNonexistentChildFile(name,".vog",true);
  if(!file.replaceWithData(data.getData(),data.getSize()))return juce::Result::fail("Could not write user patch");
  savedName=file.getFileNameWithoutExtension();
  return juce::Result::ok();
 }
};
}
