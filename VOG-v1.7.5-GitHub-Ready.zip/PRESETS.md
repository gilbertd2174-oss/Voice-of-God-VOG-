# 200 Factory Sounds

01–20: original collection. 21–36: bass. 37–52: leads. 53–68: pads and strings. 69–84: keys, plucks and organs. 85–100: arpeggios and experimental sounds.

- 01 • Walnut Poly
- 02 • Velvet Strings
- 03 • Rubber Bass
- 04 • Copper Lead
- 05 • Neon Steps
- 06 • Moon Glass
- 07 • Broken Radio
- 08 • Cathedral Pad
- 09 • Plucked Circuit
- 10 • Hollow Pulse
- 11 • Desert Brass
- 12 • Deep Sine
- 13 • Tape Orbit
- 14 • Acid Lantern
- 15 • Fuzz Organ
- 16 • Slow Tide
- 17 • Clockwork Random
- 18 • Wide Cinema
- 19 • Percussive Noise
- 20 • Init / Dry
- 21 • Four Pole Bass
- 22 • Roundhouse Sub
- 23 • Sawtooth Engine
- 24 • Pulse Runner
- 25 • Octave Muscle
- 26 • Liquid Copper
- 27 • Fuzz Basement
- 28 • Short Circuit Bass
- 29 • Dusk Triangle
- 30 • Hollow Machine
- 31 • Stereo Growler
- 32 • Rubber Four
- 33 • Dusty Reel Bass
- 34 • Low Brass Stack
- 35 • Modulated Undertow
- 36 • Clean Foundation
- 37 • Four Voice Crown
- 38 • Silk Portamento
- 39 • Laser Balcony
- 40 • Brass Rocket
- 41 • Electric Oboe
- 42 • Wide Detune Solo
- 43 • Moon Flute
- 44 • Fuzz Comet
- 45 • Resonant Needle
- 46 • Vintage Syncopation
- 47 • PWM Lighthouse
- 48 • Glass Beam
- 49 • Velvet Scream
- 50 • Retro Game Hero
- 51 • Descending Spark
- 52 • Golden Horizon
- 53 • Four Seasons Pad
- 54 • Walnut Orchestra
- 55 • Cloud Cathedral
- 56 • Slow Aurora
- 57 • Pulse Velvet
- 58 • Frozen Glass Choir
- 59 • Low Strings
- 60 • High Silk Strings
- 61 • Deep Space Air
- 62 • Violet Motion
- 63 • Warm Tape Ensemble
- 64 • Shimmering Octaves
- 65 • Dark Room Drone
- 66 • Emerald Swell
- 67 • Midnight Hollow
- 68 • Cinema Sunrise
- 69 • Four Osc Electric Piano
- 70 • Analog Clavinet
- 71 • Copper Marimba
- 72 • Glass Celesta
- 73 • Tape Harpsichord
- 74 • Soft Music Box
- 75 • Percussive Organ
- 76 • Rotating Combo Organ
- 77 • Fuzz Chapel Organ
- 78 • Plucked Nylon Light
- 79 • Muted Mallet
- 80 • Bright Bell Garden
- 81 • Velvet Harp
- 82 • Steel Pluck
- 83 • Low Rhodes Glow
- 84 • Choral Keyboard
- 85 • Four Osc Night Drive
- 86 • Ascending Lanterns
- 87 • Descending Starlight
- 88 • Pendulum Sequence
- 89 • Random Observatory
- 90 • Triplet Circuit
- 91 • Acid Four
- 92 • Octave Clockwork
- 93 • Tape Ping Stars
- 94 • Gated Nebula
- 95 • Robot Transmission
- 96 • Wind Particle Lab
- 97 • Glitch Meteor
- 98 • Slow Cosmic Beacon
- 99 • Mod Wheel Adventure
- 100 • Finale / Four Horizons

## New 100

### Sub Bass

- 101 • Onyx
- 102 • Pressure
- 103 • Deep Current
- 104 • Valve
- 105 • Undertow
- 106 • Coal
- 107 • Tension
- 108 • Rubble
- 109 • Iron Root
- 110 • Blackwater

### Acid Bass

- 111 • Brass Acid
- 112 • Lemon Coil
- 113 • Filament
- 114 • Wasp Wire
- 115 • Vinegar
- 116 • Bitumen
- 117 • Amber Teeth
- 118 • Oxide
- 119 • Crucible
- 120 • Phosphor

### Lead

- 121 • Ruby Beam
- 122 • Daybreak
- 123 • Quicksilver
- 124 • Vermilion
- 125 • Starlit Wire
- 126 • Meteor
- 127 • Glass Flame
- 128 • Flare
- 129 • Aurora Lead
- 130 • Crown Signal

### Keys

- 131 • Copper Keys
- 132 • Tide Keys
- 133 • Midnight Keys
- 134 • Frost Tines
- 135 • Velour Keys
- 136 • Porcelain Keys
- 137 • Rain Keys
- 138 • Opal Tines
- 139 • Blue Piano
- 140 • Soft Relay

### Pluck

- 141 • Maple Pick
- 142 • Sea Glass Pluck
- 143 • Kite String
- 144 • Nylon Drop
- 145 • Sugar Reed
- 146 • Cedar Pick
- 147 • Pearl Strings
- 148 • Mirage Pick
- 149 • Clock Pluck
- 150 • Ember Harp

### Pad

- 151 • Blue Hour
- 152 • Velvet Eclipse
- 153 • Polar Field
- 154 • Dusk Silk
- 155 • Saturn Veil
- 156 • Ocean Sky
- 157 • Night Silk
- 158 • Ultraviolet
- 159 • Daydream
- 160 • Afterlight

### Strings

- 161 • Cinema Strings
- 162 • Crimson Bow
- 163 • Ivory Ensemble
- 164 • Winter Bow
- 165 • Twilight Strings
- 166 • Viola Sky
- 167 • Willow Strings
- 168 • Wide Quartet
- 169 • Velvet Bow
- 170 • Golden Ensemble

### Bell

- 171 • Silver Bell
- 172 • Copper Chime
- 173 • Celeste
- 174 • Star Bell
- 175 • Ice Chime
- 176 • Moon Tines
- 177 • Quartz Bells
- 178 • Orbit Bell
- 179 • Halo Chimes
- 180 • Lantern Bells

### Scale Arp

- 181 • Scale Relay
- 182 • Minor Signal
- 183 • Dawn Steps
- 184 • Silk Steps
- 185 • Night Run
- 186 • Chromatic Pilot
- 187 • Upward Spiral
- 188 • Downward Spiral
- 189 • Scale Dial
- 190 • Pulse Garden

### Chord Arp

- 191 • Chord Relay
- 192 • Minor Engine
- 193 • Suspended Air
- 194 • Open Fourth
- 195 • Seventh Street
- 196 • Major Lights
- 197 • Minor Velvet
- 198 • Chord Pulse
- 199 • Chord Drift
- 200 • Chord Finale
