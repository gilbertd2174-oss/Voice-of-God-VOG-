#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <new>
juce::AudioProcessorValueTreeState::ParameterLayout DavoeSynthProcessor::layout(){
 juce::AudioProcessorValueTreeState::ParameterLayout l;
 for(const auto& s:davoe::specs){
  juce::ParameterID id(s.id,1);
  if(s.choices[0]){auto list=juce::StringArray::fromTokens(s.choices,"|","");l.add(std::make_unique<juce::AudioParameterChoice>(id,s.name,list,(int)s.initial));}
  else l.add(std::make_unique<juce::AudioParameterFloat>(id,s.name,juce::NormalisableRange<float>(s.lo,s.hi,s.step,s.skew),s.initial));
 }return l;
}
DavoeSynthProcessor::DavoeSynthProcessor():AudioProcessor(BusesProperties().withOutput("Stereo output",juce::AudioChannelSet::stereo(),true)),state(*this,nullptr,"DAVOE_SYNTH",layout()){
 for(size_t i=0;i<raw.size();i++)raw[i]=state.getRawParameterValue(davoe::specs[i].id);
}
davoe::Values DavoeSynthProcessor::values()const{
 davoe::Values p{};
 for(size_t i=0;i<p.size();i++)p[i]=raw[i]->load();
 if(p[davoe::VelocityCurve]==0.f)
  p[davoe::VelocityCurve]=wrapperType==wrapperType_Standalone?2.f:1.f;
 return p;
}
void DavoeSynthProcessor::prepareToPlay(double rate,int){{const juce::SpinLock::ScopedLockType lock(captureLock);capture.stop();recording.store(false);captureRate.store(std::isfinite(rate)&&rate>=8000&&rate<=192000?(unsigned int)std::lround(rate):0u);}engine.prepare(rate);engine.setParameters(values(),true);keyboard.reset();transportWasPlaying=false;}
void DavoeSynthProcessor::releaseResources(){const juce::SpinLock::ScopedLockType lock(captureLock);capture.stop();recording.store(false);captureRate.store(0);}
juce::Result DavoeSynthProcessor::startRecording(){
 const auto rate=captureRate.load();davoe::WaveCapture next;
 try{if(!next.begin(rate))return juce::Result::fail("Enable audio at 8–192 kHz before recording");}
 catch(const std::bad_alloc&){return juce::Result::fail("Not enough memory to record");}
 const juce::SpinLock::ScopedLockType lock(captureLock);
 if(captureRate.load()!=rate)return juce::Result::fail("Audio device changed; try recording again");
 std::swap(capture,next);recordedSeconds.store(0);recording.store(true);return juce::Result::ok();
}
void DavoeSynthProcessor::stopRecording(){const juce::SpinLock::ScopedLockType lock(captureLock);capture.stop();recording.store(false);}
juce::Result DavoeSynthProcessor::saveRecording(const juce::File& f){
 const juce::SpinLock::ScopedLockType lock(captureLock);
 if(!capture.finishHeader(true))return juce::Result::fail("Stop a recording before saving");
 return f.withFileExtension("wav").replaceWithData(capture.data(),capture.size())?juce::Result::ok():juce::Result::fail("Could not save WAV");
}
bool DavoeSynthProcessor::isBusesLayoutSupported(const BusesLayout& b)const{return b.getMainInputChannelSet().isDisabled()&&b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo();}
void DavoeSynthProcessor::midi(const juce::MidiMessage& m){int ch=juce::jlimit(0,15,m.getChannel()-1);
 if(m.isNoteOn())engine.noteOn(m.getNoteNumber(),m.getFloatVelocity(),ch);
 else if(m.isNoteOff())engine.noteOff(m.getNoteNumber(),ch);
 else if(m.isPitchWheel())engine.pitchWheel(m.getPitchWheelValue(),ch);
 else if(m.isController())engine.controller(m.getControllerNumber(),m.getControllerValue(),ch);
 else if(m.isAllNotesOff()||m.isAllSoundOff())engine.panic();
}
void DavoeSynthProcessor::processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer& events){
 juce::ScopedNoDenormals noDenormals;b.clear();engine.setParameters(values());
 double bpm=0;
 bool transportStopped=false;
 if(auto* head=getPlayHead())if(auto pos=head->getPosition()){
  if(auto tempo=pos->getBpm())bpm=*tempo;
  const bool playing=pos->getIsPlaying();
  transportStopped=transportWasPlaying&&!playing;
  transportWasPlaying=playing;
 }
 if(panicRequested.exchange(false)||transportStopped){engine.panic();keyboard.reset();}
 keyboard.processNextMidiBuffer(events,0,b.getNumSamples(),true);
 if(auto v=uiPitch.exchange(-1);v>=0)engine.pitchWheel(v);
 if(auto v=uiMod.exchange(-1);v>=0)engine.controller(1,v);
 const float internalBpm=raw[davoe::Tempo]->load();
 bpmMeter.store(raw[davoe::ArpClock]->load()<.5f?(float)davoe::hostTempoOr(bpm,internalBpm):internalBpm);
 auto it=events.begin(),end=events.end();float maxL=0,maxR=0;
 for(int i=0;i<b.getNumSamples();i++){
  while(it!=end&&(*it).samplePosition<=i){midi((*it).getMessage());++it;}
  float l=0,r=0;engine.sample(l,r,bpm);b.setSample(0,i,l);b.setSample(1,i,r);maxL=std::max(maxL,std::abs(l));maxR=std::max(maxR,std::abs(r));
 }
 if(recording.load()&&b.getNumChannels()>=2){const juce::SpinLock::ScopedTryLockType lock(captureLock);if(lock.isLocked()){capture.append(b.getReadPointer(0),b.getReadPointer(1),b.getNumSamples());recordedSeconds.store((float)capture.seconds());recording.store(capture.active());}}
 events.clear();peakL.store(std::max(maxL,peakL.load()*.82f));peakR.store(std::max(maxR,peakR.load()*.82f));grMeter.store(engine.gainReduction());voiceMeter.store(engine.activeVoices());
}
void DavoeSynthProcessor::setCurrentProgram(int index){if(index<0||index>=getNumPrograms())return;program.store(index);userPatchActive.store(false);auto& v=davoe::presets[(size_t)index].values;
 for(size_t i=0;i<v.size();i++)if(auto* p=state.getParameter(davoe::specs[i].id)){p->beginChangeGesture();p->setValueNotifyingHost(p->convertTo0to1(v[i]));p->endChangeGesture();}panicRequested.store(true);++patchRevision;
}
juce::String DavoeSynthProcessor::currentUserPatch()const{
 const juce::ScopedLock lock(patchNameLock);
 return userPatchActive.load()?userPatchName:juce::String();
}
void DavoeSynthProcessor::identifyUserPatch(const juce::String& name){
 const juce::ScopedLock lock(patchNameLock);
 userPatchName=name;userPatchActive.store(name.isNotEmpty());++patchRevision;
}
void DavoeSynthProcessor::getStateInformation(juce::MemoryBlock& data){
 auto tree=state.copyState();tree.setProperty("program",program.load(),nullptr);
 tree.setProperty("userPatch",currentUserPatch(),nullptr);
 if(auto xml=tree.createXml())copyXmlToBinary(*xml,data);
}
bool DavoeSynthProcessor::restorePatch(const void* data,int size,const juce::String* userName){
 auto xml=getXmlFromBinary(data,size);if(!xml||!xml->hasTagName(state.state.getType()))return false;
 auto tree=juce::ValueTree::fromXml(*xml);
 for(auto parameter:{davoe::ArpScale,davoe::ArpChord,davoe::VelocityCurve,davoe::HeldLevel,davoe::OscGate1,davoe::OscGate2,davoe::OscGate3,davoe::OscGate4}){
  const auto& spec=davoe::specs[(size_t)parameter];
  const juce::String id(spec.id);
  if(tree.getChildWithProperty("id",id).isValid())continue;
  juce::ValueTree entry("PARAM");
  entry.setProperty("id",id,nullptr);
  entry.setProperty("value",spec.initial,nullptr);
  tree.appendChild(entry,nullptr);
 }
 program.store(juce::jlimit(0,getNumPrograms()-1,(int)tree.getProperty("program",0)));
 const auto name=userName?*userName:tree.getProperty("userPatch").toString();
 state.replaceState(tree);panicRequested.store(true);identifyUserPatch(name);return true;
}
void DavoeSynthProcessor::setStateInformation(const void* data,int size){restorePatch(data,size);}
juce::AudioProcessorEditor* DavoeSynthProcessor::createEditor(){return new DavoeSynthEditor(*this);}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new DavoeSynthProcessor();}
